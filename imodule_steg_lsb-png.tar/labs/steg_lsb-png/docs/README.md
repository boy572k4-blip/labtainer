# T-STEG01: LSB Steganography Lab (steg_lsb-png)

## Cấu trúc thư mục

```
steg_lsb-png/
├── config/
│   └── lab.config              # Cấu hình chính của lab
├── sender/
│   ├── Dockerfile              # Docker image cho máy sender
│   ├── start.sh                # Script khởi động container
│   ├── start.config            # Cấu hình Labtainer cho sender
│   ├── results.config          # Cấu hình chấm điểm sender
│   └── steg_lab/
│       ├── lsb_embed.py        # Script nhúng thông điệp LSB
│       └── generate_cover.py   # Script tạo ảnh cover
├── receiver/
│   ├── Dockerfile              # Docker image cho máy receiver
│   ├── start.sh                # Script khởi động container
│   ├── start.config            # Cấu hình Labtainer cho receiver
│   ├── results.config          # Cấu hình chấm điểm receiver
│   └── steg_lab/
│       ├── lsb_extract.py      # Script trích xuất thông điệp
│       └── chi_square_test.py  # Script phân tích Chi-Square
├── build_and_push.sh           # Build & push Docker images
├── package_imodule.sh          # Đóng gói thành file .tar
└── README.md                   # File này
```

---

## Hướng dẫn Deploy (từ đầu đến cuối)

### Bước 1: Cài Docker trên máy bạn
```bash
# Ubuntu/Debian
sudo apt-get install docker.io
sudo usermod -aG docker $USER
```

### Bước 2: Clone repo và build images
```bash
git clone https://github.com/<your-user>/<your-repo>.git
cd steg_lsb-png
chmod +x build_and_push.sh package_imodule.sh
./build_and_push.sh
```
> Nhập DockerHub token khi được hỏi mật khẩu.

### Bước 3: Đóng gói imodule
```bash
./package_imodule.sh
```
File output: `dist/imodule_steg_lsb-png.tar`

### Bước 4: Upload lên GitHub
Upload file `dist/imodule_steg_lsb-png.tar` lên GitHub repo (có thể dùng Releases).

### Bước 5: Sinh viên sử dụng
```bash
# Trên LabtainerVM, sinh viên chạy:
imodule https://github.com/<user>/<repo>/raw/main/dist/imodule_steg_lsb-png.tar
labtainer steg_lsb-png
```

---

## Network Configuration
| Container | IP Address      |
|-----------|----------------|
| sender    | 172.21.0.21    |
| receiver  | 172.21.0.30    |
| gateway   | 172.21.0.1     |

SSH password cho cả hai container: `labtainer`

---

## Docker Images
- `r3xonx/steg_lsb-png.sender`
- `r3xonx/steg_lsb-png.receiver`
