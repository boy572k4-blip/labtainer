#!/usr/bin/env python3
"""
Grading script for steg_lsb-png lab.
Called by Labtainer instructor.py after extracting student artifacts.
Args: student_dir lab_name
"""
import os
import sys

def check_file_contains(student_dir, container, rel_path, keyword):
    """Kiểm tra file tồn tại và chứa keyword"""
    full_path = os.path.join(student_dir, container, 'home', 'ubuntu', rel_path)
    # Thử thêm path khác
    alt_path = os.path.join(student_dir, container, rel_path)
    for path in [full_path, alt_path]:
        if os.path.isfile(path):
            try:
                content = open(path).read()
                return keyword.lower() in content.lower()
            except:
                pass
    return False

def main():
    if len(sys.argv) < 2:
        print("Usage: grade.py <student_dir>")
        sys.exit(1)

    student_dir = sys.argv[1]
    results = {}

    # Bước 1: image_info.txt chứa Width
    results['image_info'] = check_file_contains(
        student_dir, 'steg_lsb-png.sender.student',
        'steg_lab/image_info.txt', 'Width')

    # Bước 2: size_diff.txt chứa cover_size
    results['size_diff'] = check_file_contains(
        student_dir, 'steg_lsb-png.sender.student',
        'steg_lab/size_diff.txt', 'cover_size')

    # Bước 3: lsb_analysis.txt chứa cover_R_LSB
    results['lsb_analysis'] = check_file_contains(
        student_dir, 'steg_lsb-png.sender.student',
        'steg_lab/lsb_analysis.txt', 'cover_R_LSB')

    # Bước 4: stego_image.png tồn tại trên receiver
    stego_paths = [
        os.path.join(student_dir, 'steg_lsb-png.receiver.student', 'home', 'ubuntu', 'steg_lab', 'stego_image.png'),
        os.path.join(student_dir, 'steg_lsb-png.receiver.student', 'steg_lab', 'stego_image.png'),
    ]
    results['transfer'] = any(os.path.isfile(p) for p in stego_paths)

    # Bước 5: result.txt chứa message
    results['result_txt'] = check_file_contains(
        student_dir, 'steg_lsb-png.receiver.student',
        'steg_lab/result.txt', 'message')

    # Bước 6: chi_square_result.txt chứa pvalue
    results['chi_square'] = check_file_contains(
        student_dir, 'steg_lsb-png.receiver.student',
        'steg_lab/chi_square_result.txt', 'pvalue')

    labels = {
        'image_info':  'B1 - Ghi image_info.txt',
        'size_diff':   'B2 - Ghi size_diff.txt',
        'lsb_analysis':'B3 - Ghi lsb_analysis.txt',
        'transfer':    'B4 - Truyen stego sang receiver',
        'result_txt':  'B5 - Ghi result.txt',
        'chi_square':  'B6 - Ghi chi_square_result.txt',
    }

    for key, label in labels.items():
        mark = 'Y' if results[key] else 'N'
        print(f' {mark} -  {label}')

if __name__ == '__main__':
    main()
