#!/usr/bin/env python3
# Auto-generated grading script for steg_lsb-png
import os, sys
