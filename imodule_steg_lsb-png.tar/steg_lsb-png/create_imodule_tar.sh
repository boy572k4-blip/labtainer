#!/bin/bash
# =============================================================================
#  create_imodule_tar.sh
#  Tạo file imodule_steg_lsb-png.tar để upload lên GitHub/web
#  và cài bằng lệnh: imodule <URL>/imodule_steg_lsb-png.tar
# =============================================================================
# Chạy script này trên máy LOCAL (không phải trong VM) nếu có Docker
# Hoặc trên LabtainerVM nếu muốn build trực tiếp

set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LAB_NAME="steg_lsb-png"

echo "============================================================"
echo "  TẠO IMODULE: $LAB_NAME"
echo "============================================================"

# Tạo thư mục tạm
TMPDIR=$(mktemp -d)
LABDIR="$TMPDIR/$LAB_NAME"
mkdir -p "$LABDIR"

# Copy toàn bộ lab vào tmpdir
cp -r "$SCRIPT_DIR/$LAB_NAME"/* "$LABDIR/"

# Tạo file imodule.tar
cd "$TMPDIR"
tar -cf "$SCRIPT_DIR/imodule_${LAB_NAME}.tar" "$LAB_NAME"

# Dọn dẹp
rm -rf "$TMPDIR"

echo "[OK] File tạo: $SCRIPT_DIR/imodule_${LAB_NAME}.tar"
echo ""
echo "  Upload file này lên GitHub hoặc web server"
echo "  Sau đó trên VM chạy:"
echo "    imodule https://your-url/imodule_${LAB_NAME}.tar"
echo "    labtainer $LAB_NAME"
