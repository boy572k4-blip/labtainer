#!/bin/bash
REGISTRY="r3xonx"
LAB="steg_lsb-png"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "=============================================="
echo " Build & Push: $LAB"
echo " $REGISTRY/${LAB}.sender.student"
echo " $REGISTRY/${LAB}.receiver.student"
echo "=============================================="

docker login -u "$REGISTRY"
[ $? -ne 0 ] && echo "[ERROR] Login thất bại!" && exit 1

echo "[BUILD] sender..."
cd "$SCRIPT_DIR/sender" && docker build -t "$REGISTRY/${LAB}.sender.student:latest" .
[ $? -ne 0 ] && echo "[ERROR] Build sender thất bại!" && exit 1

echo "[BUILD] receiver..."
cd "$SCRIPT_DIR/receiver" && docker build -t "$REGISTRY/${LAB}.receiver.student:latest" .
[ $? -ne 0 ] && echo "[ERROR] Build receiver thất bại!" && exit 1

echo "[PUSH] sender..."
docker push "$REGISTRY/${LAB}.sender.student:latest"
echo "[PUSH] receiver..."
docker push "$REGISTRY/${LAB}.receiver.student:latest"

echo "=============================================="
echo " HOÀN THÀNH!"
echo "=============================================="
