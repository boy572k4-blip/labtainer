#!/bin/bash
# ============================================================
# build_and_push.sh
# Dùng: ./build_and_push.sh
# ============================================================

REGISTRY="r3xonx"
LAB="steg_lsb-png"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "=============================================="
echo " Labtainer Build & Push: $LAB"
echo " Images cần có trên DockerHub:"
echo "   $REGISTRY/${LAB}.sender.student"
echo "   $REGISTRY/${LAB}.receiver.student"
echo "=============================================="

# Login
echo ""
echo "[STEP 1] Đăng nhập DockerHub (nhập token khi hỏi password)..."
docker login -u "$REGISTRY"
[ $? -ne 0 ] && echo "[ERROR] Login thất bại!" && exit 1

# --- Nếu đã có image cũ (r3xonx/steg_lsb-png.sender), retag thay vì build lại ---
OLD_SENDER="$REGISTRY/${LAB}.sender"
OLD_RECEIVER="$REGISTRY/${LAB}.receiver"
NEW_SENDER="$REGISTRY/${LAB}.sender.student"
NEW_RECEIVER="$REGISTRY/${LAB}.receiver.student"

if docker image inspect "$OLD_SENDER:latest" > /dev/null 2>&1; then
    echo ""
    echo "[INFO] Tìm thấy image cũ → Retag (không cần build lại)..."
    docker tag "$OLD_SENDER:latest" "$NEW_SENDER:latest"
    docker tag "$OLD_RECEIVER:latest" "$NEW_RECEIVER:latest"
    echo "[OK] Retag xong!"
else
    echo ""
    echo "[STEP 2] Build sender..."
    cd "$SCRIPT_DIR/sender"
    docker build -t "$NEW_SENDER:latest" .
    [ $? -ne 0 ] && echo "[ERROR] Build sender thất bại!" && exit 1

    echo ""
    echo "[STEP 3] Build receiver..."
    cd "$SCRIPT_DIR/receiver"
    docker build -t "$NEW_RECEIVER:latest" .
    [ $? -ne 0 ] && echo "[ERROR] Build receiver thất bại!" && exit 1
fi

# Push
echo ""
echo "[STEP 4] Push lên DockerHub..."
docker push "$NEW_SENDER:latest"
docker push "$NEW_RECEIVER:latest"

echo ""
echo "=============================================="
echo " HOÀN THÀNH! Images đã push:"
echo "   $NEW_SENDER"
echo "   $NEW_RECEIVER"
echo "=============================================="
