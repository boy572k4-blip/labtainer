#!/bin/bash
REGISTRY="r3xonx"
LAB="steg_lsb-png"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

echo "=============================================="
echo " Build & Push: $LAB"
echo " $REGISTRY/${LAB}.sender.student"
echo " $REGISTRY/${LAB}.receiver.student"
echo "=============================================="

docker login -u "$REGISTRY"
[ $? -ne 0 ] && echo "[ERROR] Login thất bại!" && exit 1

# Nếu image cũ tồn tại → retag (nhanh hơn build lại)
if docker image inspect "$REGISTRY/${LAB}.sender:latest" > /dev/null 2>&1; then
    echo "[INFO] Retag image cũ..."
    docker tag "$REGISTRY/${LAB}.sender:latest"   "$REGISTRY/${LAB}.sender.student:latest"
    docker tag "$REGISTRY/${LAB}.receiver:latest" "$REGISTRY/${LAB}.receiver.student:latest"
else
    echo "[BUILD] sender..."
    cd "$SCRIPT_DIR/sender" && docker build -t "$REGISTRY/${LAB}.sender.student:latest" .
    [ $? -ne 0 ] && exit 1
    echo "[BUILD] receiver..."
    cd "$SCRIPT_DIR/receiver" && docker build -t "$REGISTRY/${LAB}.receiver.student:latest" .
    [ $? -ne 0 ] && exit 1
fi

docker push "$REGISTRY/${LAB}.sender.student:latest"
docker push "$REGISTRY/${LAB}.receiver.student:latest"

echo "=============================================="
echo " HOÀN THÀNH!"
echo "=============================================="
