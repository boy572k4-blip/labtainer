#!/bin/bash
# build_imodule.sh - Tạo file imodule để cài vào Labtainer VM
# Chạy script này trên máy có Docker để build images và tạo package

set -e

LAB_NAME="steg_lsb-png"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LAB_DIR="$SCRIPT_DIR/$LAB_NAME"
OUTPUT_DIR="$SCRIPT_DIR/output"

echo "========================================================"
echo "  BUILD LABTAINER LAB: $LAB_NAME"
echo "========================================================"

mkdir -p "$OUTPUT_DIR"

# ---- Bước 1: Build Docker images ----
echo "[1/4] Building Docker images..."

echo "  Building sender image..."
docker build -t "labtainer.$LAB_NAME.sender" "$LAB_DIR/sender/" \
    --label "labtainer=true" \
    --label "lab=$LAB_NAME" \
    --label "container=sender"
echo "  [OK] sender image built"

echo "  Building receiver image..."
docker build -t "labtainer.$LAB_NAME.receiver" "$LAB_DIR/receiver/" \
    --label "labtainer=true" \
    --label "lab=$LAB_NAME" \
    --label "container=receiver"
echo "  [OK] receiver image built"

# ---- Bước 2: Tạo cấu trúc imodule ----
echo "[2/4] Creating imodule structure..."

IMOD_DIR="$OUTPUT_DIR/imodule_${LAB_NAME}"
rm -rf "$IMOD_DIR"
mkdir -p "$IMOD_DIR/docker"
mkdir -p "$IMOD_DIR/config"

# Copy config files
cp -r "$LAB_DIR/config/"* "$IMOD_DIR/config/"

# Export Docker images
echo "[3/4] Exporting Docker images (this may take a few minutes)..."
docker save "labtainer.$LAB_NAME.sender"   | gzip > "$IMOD_DIR/docker/${LAB_NAME}_sender.tar.gz"
docker save "labtainer.$LAB_NAME.receiver" | gzip > "$IMOD_DIR/docker/${LAB_NAME}_receiver.tar.gz"
echo "  [OK] Images exported"

# ---- Bước 3: Tạo metadata ----
echo "[4/4] Creating imodule package..."

cat > "$IMOD_DIR/imodule.config" << IMEOF
LAB_NAME=$LAB_NAME
VERSION=1.0
DESCRIPTION=LSB Steganography in PNG Images
CONTAINERS=sender receiver
AUTHOR=Labtainer
IMEOF

# Tạo file tar (imodule package)
cd "$OUTPUT_DIR"
tar -czf "imodule_${LAB_NAME}.tar" "$IMOD_DIR/"
echo "[OK] imodule package created: $OUTPUT_DIR/imodule_${LAB_NAME}.tar"

echo ""
echo "========================================================"
echo "  BUILD HOÀN THÀNH!"
echo ""
echo "  File imodule: $OUTPUT_DIR/imodule_${LAB_NAME}.tar"
echo ""
echo "  Upload lên GitHub hoặc web server, sau đó trên VM chạy:"
echo "  imodule <URL>/imodule_${LAB_NAME}.tar"
echo "========================================================"
