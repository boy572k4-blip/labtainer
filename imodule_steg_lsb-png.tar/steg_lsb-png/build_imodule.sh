#!/bin/bash
# build_imodule.sh
# Script đóng gói lab thành file .tar để dùng với lệnh imodule
# Chạy từ thư mục cha của steg_lsb-png/

set -e

LAB_NAME="steg_lsb-png"
OUTPUT="imodule_steg_lsb-png.tar"

echo "[*] Đang đóng gói lab '$LAB_NAME' thành '$OUTPUT'..."
tar -cvf "$OUTPUT" "$LAB_NAME/"
echo "[+] Xong! File: $OUTPUT"
echo ""
echo "Upload file '$OUTPUT' lên GitHub Release, sau đó sinh viên dùng:"
echo "  imodule https://<raw_url>/$OUTPUT"
