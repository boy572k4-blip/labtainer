#!/bin/bash
# startup.sh – Chạy khi container sender khởi động

echo "[*] Đang chuẩn bị môi trường lab steganography..."

# Tạo thư mục nếu chưa có
mkdir -p /root/steg_lab

# Tạo cover image
cd /root/steg_lab
python3 /root/steg_lab/generate_cover.py

# Cấu hình SSH để không hỏi host key khi scp
mkdir -p /root/.ssh
cat > /root/.ssh/config << 'EOF'
Host *
    StrictHostKeyChecking no
    UserKnownHostsFile /dev/null
EOF
chmod 600 /root/.ssh/config

# Khởi động SSH daemon
service ssh start 2>/dev/null || true

echo ""
echo "==========================================="
echo "  LAB T-STEG01: LSB Steganography"
echo "  Máy: SENDER (172.21.0.20)"
echo "==========================================="
echo ""
echo "  Thư mục lab: ~/steg_lab/"
echo "  File ảnh gốc: ~/steg_lab/cover_image.png"
echo ""
echo "  Bắt đầu bằng lệnh:"
echo "  ls ~/steg_lab/"
echo "==========================================="
