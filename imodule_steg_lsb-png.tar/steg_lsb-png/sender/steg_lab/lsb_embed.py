#!/usr/bin/env python3
"""
lsb_embed.py - Nhúng thông điệp bí mật vào ảnh PNG bằng kỹ thuật LSB
(Least Significant Bit Steganography)

Cách hoạt động:
  1. Chuyển thông điệp thành chuỗi bit nhị phân
  2. Thêm delimiter đặc biệt để biết khi nào kết thúc
  3. Thay thế bit thấp nhất (LSB) của từng kênh màu (R,G,B) bằng bit của thông điệp
  4. Lưu ảnh kết quả

Dung lượng tối đa: (W × H × 3) / 8 bytes
"""

import sys
import os
import argparse

try:
    from PIL import Image
except ImportError:
    os.system("pip3 install Pillow --break-system-packages 2>/dev/null || pip3 install Pillow")
    from PIL import Image


# Delimiter đánh dấu kết thúc thông điệp (16 bytes null = 128 bit 0)
END_DELIMITER = '\x00' * 16


def text_to_bits(text):
    """Chuyển chuỗi văn bản thành danh sách bit"""
    bits = []
    for char in text:
        byte = ord(char)
        for i in range(7, -1, -1):
            bits.append((byte >> i) & 1)
    return bits


def embed_message(cover_path, stego_path, message):
    """Nhúng thông điệp vào ảnh PNG bằng LSB"""
    # Mở ảnh cover
    try:
        img = Image.open(cover_path)
    except FileNotFoundError:
        print(f"[ERROR] Không tìm thấy ảnh: {cover_path}")
        sys.exit(1)

    if img.mode != 'RGB':
        img = img.convert('RGB')
        print(f"[INFO] Đã chuyển ảnh sang mode RGB")

    width, height = img.size
    pixels = [img.getpixel((x,y)) for y in range(img.size[1]) for x in range(img.size[0])]

    # Kiểm tra dung lượng
    max_bytes = (width * height * 3) // 8
    full_message = message + END_DELIMITER
    msg_bytes = len(full_message.encode('utf-8'))

    print(f"[INFO] Ảnh cover: {cover_path}")
    print(f"       Kích thước: {width}x{height} pixels")
    print(f"       Dung lượng tối đa: {max_bytes} bytes")
    print(f"[INFO] Thông điệp: '{message}'")
    print(f"       Kích thước thông điệp (kèm delimiter): {msg_bytes} bytes")

    if msg_bytes > max_bytes:
        print(f"[ERROR] Thông điệp quá dài! Tối đa {max_bytes} bytes, cần {msg_bytes} bytes.")
        sys.exit(1)

    # Chuyển thông điệp thành bit
    message_bits = text_to_bits(full_message)
    total_bits = len(message_bits)
    bit_index = 0

    # Nhúng bit vào LSB của từng kênh màu
    new_pixels = []
    for pixel in pixels:
        r, g, b = pixel[0], pixel[1], pixel[2]

        # Kênh R
        if bit_index < total_bits:
            r = (r & 0xFE) | message_bits[bit_index]
            bit_index += 1

        # Kênh G
        if bit_index < total_bits:
            g = (g & 0xFE) | message_bits[bit_index]
            bit_index += 1

        # Kênh B
        if bit_index < total_bits:
            b = (b & 0xFE) | message_bits[bit_index]
            bit_index += 1

        new_pixels.append((r, g, b))

    # Tạo ảnh stego
    stego_img = Image.new('RGB', (width, height))
    stego_img.putdata(new_pixels)

    # Đảm bảo thư mục output tồn tại
    os.makedirs(os.path.dirname(os.path.abspath(stego_path)), exist_ok=True)
    stego_img.save(stego_path, 'PNG')

    print(f"[OK] Đã nhúng thành công {bit_index} bits ({bit_index//8} bytes).")
    print(f"     Ảnh stego đã lưu: {stego_path}")

    # Thống kê thay đổi pixel
    cover_pixels = list(Image.open(cover_path).convert('RGB').getdata())
    changed = sum(1 for a, b_pix in zip(cover_pixels, new_pixels) if a != b_pix)
    print(f"[INFO] Số pixel bị thay đổi: {changed}/{len(new_pixels)} ({100*changed/len(new_pixels):.2f}%)")
    print(f"[INFO] Thay đổi tối đa mỗi kênh: ±1 (không thể phân biệt bằng mắt thường)")

    return stego_img


def main():
    parser = argparse.ArgumentParser(
        description='LSB Steganography - Nhúng thông điệp vào ảnh PNG',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Ví dụ:
  python3 lsb_embed.py --input cover.png --output stego.png --message "Hello World"
  python3 lsb_embed.py --input cover.png --output stego.png --message "BIET_TEN_TOI_KHONG"
        """
    )
    parser.add_argument('--input',   '-i', required=True, help='Đường dẫn ảnh cover PNG')
    parser.add_argument('--output',  '-o', required=True, help='Đường dẫn ảnh stego PNG (output)')
    parser.add_argument('--message', '-m', required=True, help='Thông điệp bí mật cần nhúng')

    args = parser.parse_args()

    print("=" * 60)
    print("  LSB STEGANOGRAPHY - NHÚNG THÔNG ĐIỆP VÀO ẢNH PNG")
    print("=" * 60)
    embed_message(args.input, args.output, args.message)
    print("=" * 60)


if __name__ == '__main__':
    main()
