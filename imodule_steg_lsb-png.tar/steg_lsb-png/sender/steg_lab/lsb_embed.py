#!/usr/bin/env python3
"""LSB Steganography - Embed thông điệp vào ảnh PNG"""
import argparse
from PIL import Image
import sys

DELIMITER = "<<END>>"

def text_to_bits(text):
    bits = []
    for char in text:
        byte = ord(char)
        for i in range(7, -1, -1):
            bits.append((byte >> i) & 1)
    return bits

def embed_message(input_path, output_path, message):
    img = Image.open(input_path).convert('RGB')
    pixels = list(img.getdata())
    width, height = img.size

    full_message = message + DELIMITER
    bits = text_to_bits(full_message)
    max_capacity = width * height * 3

    if len(bits) > max_capacity:
        print(f"[ERROR] Thông điệp quá dài! Tối đa: {max_capacity // 8} bytes")
        sys.exit(1)

    print(f"[INFO] Ảnh gốc: {width}x{height} | Dung lượng tối đa: {max_capacity // 8} bytes")
    print(f"[INFO] Nhúng: {len(full_message)} ký tự = {len(bits)} bits")

    new_pixels = []
    bit_index = 0
    for pixel in pixels:
        r, g, b = pixel
        if bit_index < len(bits):
            r = (r & ~1) | bits[bit_index]; bit_index += 1
        if bit_index < len(bits):
            g = (g & ~1) | bits[bit_index]; bit_index += 1
        if bit_index < len(bits):
            b = (b & ~1) | bits[bit_index]; bit_index += 1
        new_pixels.append((r, g, b))

    new_img = Image.new('RGB', img.size)
    new_img.putdata(new_pixels)
    new_img.save(output_path, 'PNG')
    print(f"[SUCCESS] Đã lưu stego image: {output_path}")
    print(f"[INFO] Thông điệp đã nhúng: '{message}'")

def main():
    parser = argparse.ArgumentParser(description='LSB Embed')
    parser.add_argument('--input',   required=True)
    parser.add_argument('--output',  required=True)
    parser.add_argument('--message', required=True)
    args = parser.parse_args()
    embed_message(args.input, args.output, args.message)

if __name__ == '__main__':
    main()
