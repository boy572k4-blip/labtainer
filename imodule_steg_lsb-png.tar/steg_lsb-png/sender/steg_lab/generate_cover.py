#!/usr/bin/env python3
"""
generate_cover.py - Tạo ảnh PNG cover_image.png cho bài lab LSB Steganography
Ảnh được tạo với gradient màu tự nhiên để LSB thay đổi không bị phát hiện bằng mắt
"""

import sys
import os
import math
import random

try:
    from PIL import Image
except ImportError:
    print("[ERROR] Thư viện Pillow chưa được cài. Đang cài đặt...")
    os.system("pip3 install Pillow --break-system-packages 2>/dev/null || pip3 install Pillow")
    from PIL import Image

def generate_cover_image(output_path, width=640, height=480, seed=42):
    """Tạo ảnh PNG với gradient tự nhiên dùng làm cover image"""
    random.seed(seed)
    img = Image.new('RGB', (width, height))
    pixels = []

    for y in range(height):
        row = []
        for x in range(width):
            # Gradient đẹp, tự nhiên
            r = int(128 + 127 * math.sin(x / 80.0) * math.cos(y / 60.0))
            g = int(128 + 127 * math.sin(x / 100.0 + 1.5) * math.cos(y / 80.0 + 0.5))
            b = int(128 + 127 * math.sin(x / 60.0 + 3.0) * math.cos(y / 100.0 + 1.0))
            # Thêm chút noise để tự nhiên hơn
            r = max(0, min(255, r + random.randint(-5, 5)))
            g = max(0, min(255, g + random.randint(-5, 5)))
            b = max(0, min(255, b + random.randint(-5, 5)))
            row.append((r, g, b))
        pixels.extend(row)

    img.putdata(pixels)
    img.save(output_path, 'PNG')
    print(f"[OK] Đã tạo cover image: {output_path}")
    print(f"     Kích thước: {width}x{height} pixels")
    print(f"     Dung lượng nhúng tối đa: {(width * height * 3) // 8} bytes")
    return img

if __name__ == "__main__":
    output = sys.argv[1] if len(sys.argv) > 1 else "/root/steg_lab/cover_image.png"
    os.makedirs(os.path.dirname(output), exist_ok=True)
    generate_cover_image(output)
