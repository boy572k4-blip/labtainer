#!/usr/bin/env python3
"""Tạo ảnh cover_image.png 512x512 cho bài lab steganography"""
from PIL import Image
import random, math

random.seed(42)
width, height = 512, 512
img = Image.new('RGB', (width, height))
pixels = []
for y in range(height):
    for x in range(width):
        r = int(128 + 100*math.sin(x*0.05) + random.randint(-10,10))
        g = int(128 + 100*math.cos(y*0.05) + random.randint(-10,10))
        b = int(128 + 80 *math.sin((x+y)*0.03) + random.randint(-10,10))
        pixels.append((max(0,min(255,r)), max(0,min(255,g)), max(0,min(255,b))))
img.putdata(pixels)
img.save('/root/steg_lab/cover_image.png', 'PNG')
print(f"[OK] cover_image.png: {width}x{height} pixels")
