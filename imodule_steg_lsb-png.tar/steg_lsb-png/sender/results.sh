#!/bin/bash
# Script kiểm tra kết quả và ghi vào result files cho Labtainer grader
RESULT_DIR=/home/ubuntu/.local/result

mkdir -p $RESULT_DIR

# Check cover_image.png
if [ -f /home/ubuntu/steg_lab/cover_image.png ]; then
    echo "1" > $RESULT_DIR/cover_image
else
    echo "0" > $RESULT_DIR/cover_image
fi

# Check stego_image.png
if [ -f /home/ubuntu/steg_lab/stego_image.png ]; then
    echo "1" > $RESULT_DIR/stego_image
else
    echo "0" > $RESULT_DIR/stego_image
fi

chown -R ubuntu:ubuntu $RESULT_DIR
