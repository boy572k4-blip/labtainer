#!/bin/bash
service ssh start

# Tạo thư mục lab cho ubuntu
mkdir -p /home/ubuntu/steg_lab
chown -R ubuntu:ubuntu /home/ubuntu/steg_lab

# Symlink để root cũng dùng được ~/steg_lab/
ln -sfn /home/ubuntu/steg_lab /root/steg_lab

# Tạo cover_image.png nếu chưa có
if [ ! -f /home/ubuntu/steg_lab/cover_image.png ]; then
    echo "[INIT] Tao cover_image.png..."
    python3 /home/ubuntu/steg_lab/generate_cover.py
    chown ubuntu:ubuntu /home/ubuntu/steg_lab/cover_image.png 2>/dev/null
fi

echo "[READY] Sender san sang! IP: 172.21.0.21"
echo "[INFO]  Thu muc lab: /home/ubuntu/steg_lab  hoac  ~/steg_lab"
tail -f /dev/null
