#!/bin/bash
service ssh start 2>/dev/null

mkdir -p /var/labtainer
echo "steg_lsb-png_seed" > /var/labtainer/seed

mkdir -p /home/ubuntu/.local
echo "student@labtainer.local" > /home/ubuntu/.local/.email
echo "steg_lsb-png" > /home/ubuntu/.local/.labname
chown -R ubuntu:ubuntu /home/ubuntu/.local

touch /var/labtainer/did_param

mkdir -p /home/ubuntu/steg_lab
chown -R ubuntu:ubuntu /home/ubuntu/steg_lab

# Tạo file placeholder để checkwork luôn hiển thị N nếu chưa làm
touch /home/ubuntu/steg_lab/image_info.txt
touch /home/ubuntu/steg_lab/size_diff.txt
touch /home/ubuntu/steg_lab/lsb_analysis.txt
chown ubuntu:ubuntu /home/ubuntu/steg_lab/*.txt

if [ ! -f /home/ubuntu/steg_lab/cover_image.png ]; then
    python3 /home/ubuntu/steg_lab/generate_cover.py 2>/dev/null
    chown ubuntu:ubuntu /home/ubuntu/steg_lab/cover_image.png 2>/dev/null
fi

tail -f /dev/null
