#!/bin/bash
service ssh start

# Tạo /var/labtainer/ và ghi seed (Labtainer GoalsParser yêu cầu)
mkdir -p /var/labtainer
echo "steg_lsb-png_seed" > /var/labtainer/seed

# Tạo thư mục lab cho ubuntu
mkdir -p /home/ubuntu/steg_lab
chown -R ubuntu:ubuntu /home/ubuntu/steg_lab

# Symlink để root dùng được ~/steg_lab/
ln -sfn /home/ubuntu/steg_lab /root/steg_lab

# Tạo cover_image.png nếu chưa có
if [ ! -f /home/ubuntu/steg_lab/cover_image.png ]; then
    echo "[INIT] Tao cover_image.png..."
    python3 /home/ubuntu/steg_lab/generate_cover.py
    chown ubuntu:ubuntu /home/ubuntu/steg_lab/cover_image.png 2>/dev/null
fi

echo "[READY] Sender san sang! IP: 172.21.0.21"
echo "[INFO]  Thu muc lab: ~/steg_lab/"
tail -f /dev/null
