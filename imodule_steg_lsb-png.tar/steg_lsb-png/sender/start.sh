#!/bin/bash
# Tạo cover_image.png nếu chưa có
if [ ! -f /home/ubuntu/steg_lab/cover_image.png ]; then
    python3 /home/ubuntu/steg_lab/generate_cover.py
    chown ubuntu:ubuntu /home/ubuntu/steg_lab/cover_image.png 2>/dev/null
fi
