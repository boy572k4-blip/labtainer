#!/bin/bash
service ssh start

# Tạo ảnh cover nếu chưa có
if [ ! -f /home/ubuntu/steg_lab/cover_image.png ]; then
    echo "[INIT] Tạo cover_image.png..."
    sudo -u ubuntu python3 /home/ubuntu/steg_lab/generate_cover.py
fi

echo "[READY] Sender sẵn sàng! IP: 172.21.0.21"
tail -f /dev/null
