#!/bin/bash
service ssh start
echo "[INIT] Tạo ảnh cover_image.png..."
python3 /root/steg_lab/generate_cover.py
echo "[READY] Sender sẵn sàng! IP: 172.21.0.21"
echo "[INFO] Workspace: /root/steg_lab/"
tail -f /dev/null
