#!/bin/bash
service ssh start

# Tạo cover_image nếu chưa có
if [ ! -f /home/ubuntu/steg_lab/cover_image.png ]; then
    echo "[INIT] Tạo cover_image.png..."
    sudo -u ubuntu python3 /home/ubuntu/steg_lab/generate_cover.py
fi

echo "[READY] Sender sẵn sàng! IP: 172.21.0.21"
tail -f /dev/null

# Chạy result check khi khởi động
bash /home/ubuntu/results.sh
# Watch và update results liên tục
while true; do
    bash /home/ubuntu/results.sh
    sleep 10
done &
