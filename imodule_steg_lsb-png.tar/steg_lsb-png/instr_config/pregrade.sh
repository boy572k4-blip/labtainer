#!/bin/bash
MYHOME=$1
DEST=$2
mkdir -p "$MYHOME/$DEST/.local/result"
exit 0
