#!/bin/bash
# pregrade.sh - chạy trước khi grade, không cần seed
MYHOME=$1
DEST=$2

# Tìm file trong zip đã giải nén
SENDER_DIR="$MYHOME/$DEST/../steg_lsb-png.sender.student"
RECEIVER_DIR="$MYHOME/$DEST/../steg_lsb-png.receiver.student"

# Tạo result files để ResultParser đọc được
mkdir -p "$MYHOME/$DEST/.local/result"

exit 0
