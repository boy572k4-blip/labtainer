# T-STEG01: LSB Steganography in PNG — Labtainer Lab

Lab thực hành kỹ thuật **giấu tin trong ảnh (steganography)** sử dụng phương pháp LSB (Least Significant Bit).

## Yêu cầu
- **LabtainerVM** (đã có sẵn Docker + Labtainer)
- Kết nối internet **KHÔNG bắt buộc** — lab dùng `labtainer.base` image có sẵn trong VM

## Cài đặt & Chạy (1 lệnh)

```bash
imodule https://github.com/<USER>/<REPO>/raw/main/imodule_steg_lsb-png.tar
labtainer steg_lsb-png
```

Labtainer sẽ tự mở **2 terminal ảo**: một cho `sender`, một cho `receiver`.

---

## Luồng thực hành

### Terminal SENDER (172.21.0.20)

```bash
# 1. Xem ảnh gốc
ls ~/steg_lab/
python3 -c "
from PIL import Image
img = Image.open('/root/steg_lab/cover_image.png')
print('Size:', img.size, '| Mode:', img.mode)
"
echo "Width=640 Height=480" > ~/steg_lab/image_info.txt

# 2. Nhúng thông điệp vào ảnh
python3 ~/steg_lab/lsb_embed.py \
    -i ~/steg_lab/cover_image.png \
    -o ~/steg_lab/stego_image.png \
    -m "BIET_TEN_TOI_KHONG"

# Ghi lại kích thước file
ls -la ~/steg_lab/cover_image.png ~/steg_lab/stego_image.png
echo "cover_size=<bytes> stego_size=<bytes>" > ~/steg_lab/size_diff.txt

# 3. Phân tích LSB pixel đầu tiên
python3 -c "
from PIL import Image
c = Image.open('/root/steg_lab/cover_image.png')
s = Image.open('/root/steg_lab/stego_image.png')
cp = c.getpixel((0,0)); sp = s.getpixel((0,0))
print('Cover pixel (0,0):', cp, '  LSB R:', cp[0] & 1)
print('Stego pixel (0,0):', sp, '  LSB R:', sp[0] & 1)
"
echo "cover_R_LSB=<0_or_1> stego_R_LSB=<0_or_1>" > ~/steg_lab/lsb_analysis.txt

# 4. Gửi ảnh stego sang receiver
scp ~/steg_lab/stego_image.png root@172.21.0.30:~/steg_lab/
# password: receiver123
```

### Terminal RECEIVER (172.21.0.30)

```bash
# 5. Trích xuất thông điệp
python3 ~/steg_lab/lsb_extract.py \
    -i ~/steg_lab/stego_image.png \
    -o ~/steg_lab/extracted_message.txt

cat ~/steg_lab/extracted_message.txt
echo "message=BIET_TEN_TOI_KHONG" > ~/steg_lab/result.txt

# 6. Chi-Square steganalysis
python3 ~/steg_lab/chi_square_test.py -i ~/steg_lab/stego_image.png
python3 ~/steg_lab/chi_square_test.py -i ~/steg_lab/cover_image.png
echo "cover_pvalue=<val> stego_pvalue=<val>" > ~/steg_lab/chi_square_result.txt
```

---

## Thông tin kỹ thuật

| Thông số | Giá trị |
|---|---|
| IP Sender | 172.21.0.20 |
| IP Receiver | 172.21.0.30 |
| SSH password (receiver) | `receiver123` |
| Kích thước ảnh | 640×480 px |
| Dung lượng nhúng tối đa | 115,200 bytes |

## Files cần nộp

**Sender:** `image_info.txt`, `size_diff.txt`, `lsb_analysis.txt`  
**Receiver:** `extracted_message.txt`, `result.txt`, `chi_square_result.txt`

## Troubleshooting

```bash
# Pillow chưa cài
pip3 install Pillow --break-system-packages

# SSH receiver không lên
/usr/sbin/sshd

# Tạo lại cover image
python3 ~/steg_lab/generate_cover.py ~/steg_lab/cover_image.png
```
