# T-STEG01: LSB Steganography in PNG Images

Bài lab thực hành kỹ thuật **giấu tin bằng LSB (Least Significant Bit)** trong ảnh PNG, sử dụng nền tảng [Labtainer](https://nps.edu/web/c3o/labtainers).

---

## Cấu trúc thư mục

```
steg_lsb-png/
├── config/
│   ├── environment.config   # Cấu hình mạng, container, IP
│   └── lab.config           # Thông tin lab
├── dockerfiles/
│   ├── Dockerfile.sender    # Image cho máy sender
│   └── Dockerfile.receiver  # Image cho máy receiver
├── sender/
│   └── steg_lab/
│       ├── generate_cover.py   # Tạo ảnh gốc
│       ├── lsb_embed.py        # Nhúng thông điệp vào ảnh
│       └── chi_square_test.py  # Phân tích thống kê
├── receiver/
│   └── steg_lab/
│       ├── lsb_extract.py      # Trích xuất thông điệp
│       └── chi_square_test.py  # Phân tích thống kê
├── docker-compose.yml       # Chạy lab bằng Docker Compose
├── build_imodule.sh         # Đóng gói thành .tar cho imodule
└── README.md
```

---

## Cách chạy bằng Docker Compose (không cần Labtainer)

> **Yêu cầu:** Docker và Docker Compose đã được cài đặt.

```bash
# Clone repo
git clone https://github.com/boy572k4-blip/labtainer.git
cd labtainer/steg_lsb-png

# Build và khởi động các container
docker-compose up -d --build

# Mở terminal cho máy sender
docker exec -it steg_lsb-png.sender bash

# Mở terminal mới cho máy receiver
docker exec -it steg_lsb-png.receiver bash
```

---

## Cách chạy bằng Labtainer (chính thức)

> **Yêu cầu:** Đã cài Labtainer trên máy.

```bash
# Tải module lab
imodule https://github.com/boy572k4-blip/labtainer/raw/main/imodule_steg_lsb-png.tar

# Khởi động lab
labtainer steg_lsb-png
```

---

## Hướng dẫn thực hành

Chi tiết xem file [`docs/lab_instructions.md`](docs/lab_instructions.md) hoặc tài liệu phát tay của môn học.

### Tóm tắt các bước:

| Bước | Máy     | Việc làm |
|------|---------|----------|
| 1    | sender  | Xem thông tin ảnh gốc `cover_image.png` |
| 2    | sender  | Nhúng thông điệp bằng `lsb_embed.py` |
| 3    | sender  | So sánh pixel LSB trước/sau nhúng |
| 4    | sender  | `scp` ảnh stego sang receiver |
| 5    | receiver| Trích xuất thông điệp bằng `lsb_extract.py` |
| 6    | receiver| Phân tích Chi-Square bằng `chi_square_test.py` |

---

## Kỹ thuật

| Thuộc tính | Chi tiết |
|---|---|
| Kỹ thuật | LSB Insertion vào kênh R/G/B của PNG |
| Dung lượng tối đa | (W × H × 3) / 8 bytes |
| Phát hiện bằng mắt | Gần như không thể |
| Công cụ phát hiện | Chi-Square Attack |
