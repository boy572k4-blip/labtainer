# T-STEG01: LSB Steganography Lab — Hướng Dẫn Triển Khai

## Cấu Trúc Thư Mục

```
steg_lsb-png/
├── config/
│   ├── lab.config          # Cấu hình chính của lab
│   ├── sender.container    # Cấu hình container sender
│   ├── receiver.container  # Cấu hình container receiver
│   └── network.config      # Cấu hình mạng ảo
│
├── sender/                 # Container máy gửi
│   ├── Dockerfile
│   ├── bin/
│   │   └── sender_start.sh
│   └── steg_lab/
│       ├── generate_cover.py   ← Tạo ảnh PNG cover
│       ├── lsb_embed.py        ← Nhúng thông điệp vào ảnh
│       ├── lsb_extract.py      ← Trích xuất thông điệp
│       └── chi_square_test.py  ← Phân tích thống kê
│
├── receiver/               # Container máy nhận
│   ├── Dockerfile
│   ├── bin/
│   │   └── receiver_start.sh
│   └── steg_lab/
│       ├── lsb_extract.py      ← Trích xuất thông điệp
│       └── chi_square_test.py  ← Phân tích thống kê
│
├── docker-compose.yml      # Chạy lab bằng Docker Compose
├── setup_lab.sh            ← SCRIPT CÀI ĐẶT CHÍNH
└── build_imodule.sh        # Build imodule package
```

---

## Cách Triển Khai (LabtainerVM24a)

### Phương án 1: Setup tự động (KHUYẾN NGHỊ)

```bash
# 1. Giải nén package này vào LabtainerVM
# 2. Chạy script setup
bash setup_lab.sh

# 3. Khởi động lab
labtainer steg_lsb-png
```

### Phương án 2: Thủ công từ imodule

```bash
# Trên LabtainerVM, chạy:
imodule https://github.com/YOUR_USER/YOUR_REPO/raw/main/imodule_steg_lsb-png.tar
labtainer steg_lsb-png
```

### Phương án 3: Docker Compose (không cần Labtainer)

```bash
cd steg_lsb-png
docker-compose up -d

# Vào sender
docker exec -it steg_sender bash

# Vào receiver (terminal khác)
docker exec -it steg_receiver bash
```

---

## Luồng Thực Hành Của Sinh Viên

### Trên máy SENDER (172.21.0.20):

```bash
# Bước 1: Quan sát ảnh gốc
ls ~/steg_lab/
python3 -c "from PIL import Image; img=Image.open('/root/steg_lab/cover_image.png'); print('Size:', img.size, '| Mode:', img.mode)"
echo "Width=640 Height=480" > ~/steg_lab/image_info.txt

# Bước 2: Nhúng thông điệp
python3 ~/steg_lab/lsb_embed.py \
    --input ~/steg_lab/cover_image.png \
    --output ~/steg_lab/stego_image.png \
    --message "BIET_TEN_TOI_KHONG"

ls -la ~/steg_lab/cover_image.png ~/steg_lab/stego_image.png
echo "cover_size=<bytes> stego_size=<bytes>" > ~/steg_lab/size_diff.txt

# Bước 3: Phân tích pixel LSB
python3 -c "
from PIL import Image
cover = Image.open('/root/steg_lab/cover_image.png')
stego = Image.open('/root/steg_lab/stego_image.png')
c_pix = cover.getpixel((0,0))
s_pix = stego.getpixel((0,0))
print('Cover pixel (0,0):', c_pix)
print('Stego pixel (0,0):', s_pix)
print('R cover binary:', bin(c_pix[0]))
print('R stego binary:', bin(s_pix[0]))
"
echo "cover_R_LSB=<0_or_1> stego_R_LSB=<0_or_1>" > ~/steg_lab/lsb_analysis.txt

# Bước 4: Truyền ảnh sang receiver
scp ~/steg_lab/stego_image.png receiver@172.21.0.30:~/steg_lab/
# Password: receiver123
```

### Trên máy RECEIVER (172.21.0.30):

```bash
# Bước 5: Trích xuất thông điệp
python3 ~/steg_lab/lsb_extract.py \
    --input ~/steg_lab/stego_image.png \
    --output ~/steg_lab/extracted_message.txt

cat ~/steg_lab/extracted_message.txt
echo "message=BIET_TEN_TOI_KHONG" > ~/steg_lab/result.txt

# Bước 6: Chi-Square Attack
python3 ~/steg_lab/chi_square_test.py --image ~/steg_lab/stego_image.png
python3 ~/steg_lab/chi_square_test.py --image ~/steg_lab/cover_image.png
echo "cover_pvalue=<val> stego_pvalue=<val>" > ~/steg_lab/chi_square_result.txt
```

---

## Thông Tin Kỹ Thuật

| Chi tiết | Giá trị |
|---|---|
| IP Sender | 172.21.0.20 |
| IP Receiver | 172.21.0.30 |
| SSH password (receiver) | receiver123 |
| Kích thước ảnh | 640×480 pixels |
| Dung lượng nhúng tối đa | 115,200 bytes |
| Thông điệp mẫu | BIET_TEN_TOI_KHONG |

---

## Troubleshooting

**Lỗi "Pillow not found":**
```bash
pip3 install Pillow --break-system-packages
```

**Lỗi scp không kết nối được:**
```bash
# Trên receiver, kiểm tra SSH
service ssh status
/usr/sbin/sshd  # Khởi động lại nếu cần

# Thử ping từ sender
ping 172.21.0.30
```

**Lỗi cover_image.png không tồn tại:**
```bash
python3 ~/steg_lab/generate_cover.py ~/steg_lab/cover_image.png
```

**Chi-square test cho kết quả ngược:**
- p-value cao (gần 1) = ảnh STEGO (có dữ liệu ẩn)
- p-value thấp (gần 0) = ảnh SẠCH

---

## Files Cần Nộp (Grading)

**Trên sender:**
- `~/steg_lab/image_info.txt` — kích thước ảnh
- `~/steg_lab/size_diff.txt` — chênh lệch file size
- `~/steg_lab/lsb_analysis.txt` — giá trị LSB

**Trên receiver:**
- `~/steg_lab/extracted_message.txt` — thông điệp trích xuất
- `~/steg_lab/result.txt` — kết quả
- `~/steg_lab/chi_square_result.txt` — p-value chi-square
