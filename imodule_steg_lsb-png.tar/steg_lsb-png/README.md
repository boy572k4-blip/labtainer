# T-STEG01: LSB Steganography in PNG

## Cài đặt (1 lệnh, không cần internet)

```bash
imodule https://github.com/boy572k4-blip/labtainer/raw/main/imodule_steg_lsb-png.tar
labtainer steg_lsb-png
```

> **Lưu ý:** Lab dùng `labtainers/labtainer.base` — image có sẵn trong mọi LabtainerVM, không cần pull DockerHub.

Sau khi chạy, 2 terminal ảo sẽ mở: **sender** và **receiver**.

---

## Thực hành

### SENDER (172.21.0.20)
```bash
# Bước 1 - Xem ảnh gốc
ls ~/steg_lab/
echo "Width=640 Height=480" > ~/steg_lab/image_info.txt

# Bước 2 - Nhúng thông điệp
python3 ~/steg_lab/lsb_embed.py -i ~/steg_lab/cover_image.png \
    -o ~/steg_lab/stego_image.png -m "BIET_TEN_TOI_KHONG"
echo "cover_size=<bytes> stego_size=<bytes>" > ~/steg_lab/size_diff.txt

# Bước 3 - Phân tích LSB
python3 -c "
from PIL import Image
c=Image.open('/root/steg_lab/cover_image.png')
s=Image.open('/root/steg_lab/stego_image.png')
cp=c.getpixel((0,0)); sp=s.getpixel((0,0))
print('Cover R LSB:', cp[0]&1, '| Stego R LSB:', sp[0]&1)
"
echo "cover_R_LSB=<0_hoac_1> stego_R_LSB=<0_hoac_1>" > ~/steg_lab/lsb_analysis.txt

# Bước 4 - Gửi sang receiver
scp ~/steg_lab/stego_image.png root@172.21.0.30:~/steg_lab/
# password: receiver123
```

### RECEIVER (172.21.0.30)
```bash
# Bước 5 - Trích xuất
python3 ~/steg_lab/lsb_extract.py -i ~/steg_lab/stego_image.png \
    -o ~/steg_lab/extracted_message.txt
echo "message=BIET_TEN_TOI_KHONG" > ~/steg_lab/result.txt

# Bước 6 - Chi-Square attack
python3 ~/steg_lab/chi_square_test.py -i ~/steg_lab/stego_image.png
python3 ~/steg_lab/chi_square_test.py -i ~/steg_lab/cover_image.png
echo "cover_pvalue=<val> stego_pvalue=<val>" > ~/steg_lab/chi_square_result.txt
```

## Kết thúc
```bash
stoplab steg_lsb-png
```
