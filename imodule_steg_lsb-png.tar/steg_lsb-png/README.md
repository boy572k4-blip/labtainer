# T-STEG01: LSB Steganography in PNG Images

Bài lab thực hành kỹ thuật **giấu tin LSB** trong ảnh PNG, dùng nền tảng Labtainer.

## Cấu trúc (theo chuẩn Labtainer IModule)

```
steg_lsb-png/
├── config/
│   ├── start.config
│   ├── results.config
│   ├── goals.config
│   └── receiver.results.config
├── dockerfiles/
│   ├── Dockerfile.steg_lsb-png.sender.student
│   └── Dockerfile.steg_lsb-png.receiver.student
├── sender/
│   ├── fixlocal.sh
│   ├── generate_cover.py
│   ├── lsb_embed.py
│   └── chi_square_test.py
├── receiver/
│   ├── fixlocal.sh
│   ├── lsb_extract.py
│   └── chi_square_test.py
└── README.md
```

## Cách dùng trên LabtainerVM

```bash
# 1. Tải imodule
imodule https://github.com/boy572k4-blip/labtainer/raw/main/imodule_steg_lsb-png.tar

# 2. Chạy lab
cd ~/labtainers/labtainer-student
labtainer steg_lsb-png
```

## Fix lỗi "Unable to reach DockerHub"

Lỗi này xảy ra khi Labtainer cố kéo base image từ DockerHub nhưng mạng bị chặn.
Bản này đã fix bằng cách dùng `ubuntu:20.04` thay vì `labtainer.network.ssh`.

Trước khi chạy `labtainer steg_lsb-png`, build image thủ công:

```bash
cd ~/labtainers/labtainer-student/labs/steg_lsb-png/dockerfiles

docker build -t labtainer.steg_lsb-png.sender.student \
    -f Dockerfile.steg_lsb-png.sender.student ..

docker build -t labtainer.steg_lsb-png.receiver.student \
    -f Dockerfile.steg_lsb-png.receiver.student ..
```

## Thông tin kỹ thuật

| | |
|---|---|
| Kỹ thuật | LSB Insertion, kênh R/G/B |
| Dung lượng tối đa | (512 × 512 × 3) / 8 = 98,304 bytes |
| Phát hiện | Chi-Square Attack |
| Sender IP | 172.21.0.20 |
| Receiver IP | 172.21.0.30 |
| SSH password | password |

## Hướng dẫn làm lab

### Trên máy SENDER (172.21.0.20):

```bash
cd ~/steg_lab

# 1. Xem thông tin ảnh gốc
python3 -c "
from PIL import Image
img = Image.open('cover_image.png')
w, h = img.size
with open('image_info.txt','w') as f:
    f.write('Width={}\nHeight={}\nMode={}\n'.format(w,h,img.mode))
"
cat image_info.txt

# 2. Nhúng thông điệp
python3 lsb_embed.py --input cover_image.png \
    --output stego_image.png \
    --message "BIET_TEN_TOI_KHONG"

# 3. So sánh kích thước
python3 -c "
import os
cs = os.path.getsize('cover_image.png')
ss = os.path.getsize('stego_image.png')
with open('size_diff.txt','w') as f:
    f.write('cover_size={}\nstego_size={}\ndiff={}\n'.format(cs,ss,ss-cs))
"

# 4. Phân tích LSB
python3 -c "
import numpy as np
from PIL import Image
img = Image.open('cover_image.png')
data = np.array(img)
r_lsb = int(data[:,:,0].flatten() & 1).mean() if False else float((data[:,:,0].flatten() & 1).mean())
with open('lsb_analysis.txt','w') as f:
    f.write('cover_R_LSB={:.4f}\n'.format(r_lsb))
"

# 5. Chi-square trên ảnh cover
python3 chi_square_test.py --image cover_image.png

# 6. Gửi ảnh stego sang receiver
scp stego_image.png root@receiver:/root/steg_lab/
```

### Trên máy RECEIVER (172.21.0.30):

```bash
cd ~/steg_lab

# 1. Trích xuất thông điệp
python3 lsb_extract.py --image stego_image.png
cat result.txt

# 2. Chi-square trên ảnh stego
python3 chi_square_test.py --image stego_image.png
```
