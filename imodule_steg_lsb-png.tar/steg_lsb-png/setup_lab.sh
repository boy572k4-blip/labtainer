#!/bin/bash
# =============================================================================
#  setup_lab.sh - Cài đặt lab T-STEG01 trên LabtainerVM24a
#  Chạy script này một lần để cài đặt tất cả
#  Usage: bash setup_lab.sh
# =============================================================================

set -e

LAB_NAME="steg_lsb-png"
LABTAINER_HOME="${LABTAINER_HOME:-$HOME/labtainer}"
LAB_DIR="$LABTAINER_HOME/labs/$LAB_NAME"

echo "============================================================"
echo "  SETUP: T-STEG01 - LSB Steganography Lab"
echo "  Labtainer VM24a"
echo "============================================================"

# Kiểm tra Labtainer đã cài chưa
if [ ! -d "$LABTAINER_HOME" ]; then
    echo "[ERROR] Không tìm thấy Labtainer tại: $LABTAINER_HOME"
    echo "        Hãy đảm bảo bạn đang dùng LabtainerVM24a"
    echo "        Hoặc set: export LABTAINER_HOME=/path/to/labtainer"
    exit 1
fi

echo "[1/5] Tạo cấu trúc thư mục lab..."
mkdir -p "$LAB_DIR"/{config,sender,receiver}
mkdir -p "$LAB_DIR/sender/steg_lab"
mkdir -p "$LAB_DIR/receiver/steg_lab"
mkdir -p "$LAB_DIR/sender/bin"
mkdir -p "$LAB_DIR/receiver/bin"

echo "[2/5] Tạo file cấu hình..."

cat > "$LAB_DIR/config/lab.config" << 'EOF'
LAB_MASTER_SEED=steg_lsb_png_v1
EOF

cat > "$LAB_DIR/config/sender.container" << 'EOF'
CONTAINER_NAME=sender
HOST_NAME=sender
GATEWAY=172.21.0.1
NETWORK=steg_lsb-png.network
IPADDR=172.21.0.20
IMAGE=mfthomps/labtainers.base
XTERM=YES
EOF

cat > "$LAB_DIR/config/receiver.container" << 'EOF'
CONTAINER_NAME=receiver
HOST_NAME=receiver
GATEWAY=172.21.0.1
NETWORK=steg_lsb-png.network
IPADDR=172.21.0.30
IMAGE=mfthomps/labtainers.base
XTERM=YES
EOF

echo "[3/5] Tạo Python scripts..."

# -------- generate_cover.py --------
cat > "$LAB_DIR/sender/steg_lab/generate_cover.py" << 'PYEOF'
#!/usr/bin/env python3
import sys, os, math, random
try:
    from PIL import Image
except ImportError:
    os.system("pip3 install Pillow --break-system-packages 2>/dev/null || pip3 install Pillow")
    from PIL import Image

def generate_cover_image(output_path, width=640, height=480, seed=42):
    random.seed(seed)
    img = Image.new('RGB', (width, height))
    pixels = []
    for y in range(height):
        for x in range(width):
            r = int(128 + 127 * math.sin(x/80.0) * math.cos(y/60.0))
            g = int(128 + 127 * math.sin(x/100.0 + 1.5) * math.cos(y/80.0 + 0.5))
            b = int(128 + 127 * math.sin(x/60.0 + 3.0) * math.cos(y/100.0 + 1.0))
            r = max(0, min(255, r + random.randint(-5,5)))
            g = max(0, min(255, g + random.randint(-5,5)))
            b = max(0, min(255, b + random.randint(-5,5)))
            pixels.append((r, g, b))
    img.putdata(pixels)
    img.save(output_path, 'PNG')
    print(f"[OK] Cover image: {output_path} ({width}x{height})")
    print(f"     Max embed capacity: {(width*height*3)//8} bytes")

if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "/root/steg_lab/cover_image.png"
    os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
    generate_cover_image(out)
PYEOF

# -------- lsb_embed.py --------
cat > "$LAB_DIR/sender/steg_lab/lsb_embed.py" << 'PYEOF'
#!/usr/bin/env python3
"""LSB Steganography - Embed message into PNG"""
import sys, os, argparse
try:
    from PIL import Image
except ImportError:
    os.system("pip3 install Pillow --break-system-packages 2>/dev/null || pip3 install Pillow")
    from PIL import Image

END_DELIMITER = '\x00' * 16

def text_to_bits(text):
    bits = []
    for char in text:
        byte = ord(char)
        for i in range(7, -1, -1):
            bits.append((byte >> i) & 1)
    return bits

def embed_message(cover_path, stego_path, message):
    try:
        img = Image.open(cover_path)
    except FileNotFoundError:
        print(f"[ERROR] File not found: {cover_path}"); sys.exit(1)
    if img.mode != 'RGB':
        img = img.convert('RGB')
    width, height = img.size
    pixels = list(img.getdata())
    max_bytes = (width * height * 3) // 8
    full_message = message + END_DELIMITER
    msg_bytes = len(full_message.encode('utf-8'))
    print(f"[INFO] Image: {cover_path} ({width}x{height})")
    print(f"[INFO] Max capacity: {max_bytes} bytes")
    print(f"[INFO] Message: '{message}' ({msg_bytes} bytes with delimiter)")
    if msg_bytes > max_bytes:
        print(f"[ERROR] Message too long! Max {max_bytes} bytes."); sys.exit(1)
    message_bits = text_to_bits(full_message)
    bit_index = 0
    new_pixels = []
    for pixel in pixels:
        r, g, b = pixel[0], pixel[1], pixel[2]
        if bit_index < len(message_bits):
            r = (r & 0xFE) | message_bits[bit_index]; bit_index += 1
        if bit_index < len(message_bits):
            g = (g & 0xFE) | message_bits[bit_index]; bit_index += 1
        if bit_index < len(message_bits):
            b = (b & 0xFE) | message_bits[bit_index]; bit_index += 1
        new_pixels.append((r, g, b))
    stego_img = Image.new('RGB', (width, height))
    stego_img.putdata(new_pixels)
    os.makedirs(os.path.dirname(os.path.abspath(stego_path)), exist_ok=True)
    stego_img.save(stego_path, 'PNG')
    changed = sum(1 for a, b2 in zip(list(Image.open(cover_path).convert('RGB').getdata()), new_pixels) if a != b2)
    print(f"[OK] Embedded {bit_index} bits into {stego_path}")
    print(f"[OK] Pixels changed: {changed}/{len(new_pixels)} ({100*changed/len(new_pixels):.2f}%)")

def main():
    parser = argparse.ArgumentParser(description='LSB Embed - Hide message in PNG')
    parser.add_argument('--input',   '-i', required=True)
    parser.add_argument('--output',  '-o', required=True)
    parser.add_argument('--message', '-m', required=True)
    args = parser.parse_args()
    print("="*55)
    print("  LSB STEGANOGRAPHY - EMBED")
    print("="*55)
    embed_message(args.input, args.output, args.message)
    print("="*55)

if __name__ == '__main__':
    main()
PYEOF

# -------- lsb_extract.py (dùng cho cả 2 container) --------
cat > "$LAB_DIR/receiver/steg_lab/lsb_extract.py" << 'PYEOF'
#!/usr/bin/env python3
"""LSB Steganography - Extract message from PNG"""
import sys, os, argparse
try:
    from PIL import Image
except ImportError:
    os.system("pip3 install Pillow --break-system-packages 2>/dev/null || pip3 install Pillow")
    from PIL import Image

def bits_to_text(bits):
    chars = []
    for i in range(0, len(bits)-7, 8):
        byte = 0
        for j in range(8): byte = (byte << 1) | bits[i+j]
        chars.append('\x00' if byte == 0 else (chr(byte) if 32 <= byte <= 126 or byte > 127 else '?'))
    return ''.join(chars)

def extract_message(stego_path, output_path=None):
    try:
        img = Image.open(stego_path)
    except FileNotFoundError:
        print(f"[ERROR] File not found: {stego_path}"); sys.exit(1)
    if img.mode != 'RGB': img = img.convert('RGB')
    width, height = img.size
    pixels = list(img.getdata())
    print(f"[INFO] Analyzing: {stego_path} ({width}x{height})")
    bits = []
    for pixel in pixels:
        bits.append(pixel[0] & 1)
        bits.append(pixel[1] & 1)
        bits.append(pixel[2] & 1)
    null_count = 0
    result_bits = []
    found_end = False
    for i in range(0, len(bits)-7, 8):
        bv = sum(bits[i+j] << (7-j) for j in range(8))
        result_bits.extend(bits[i:i+8])
        if bv == 0:
            null_count += 1
            if null_count >= 16:
                result_bits = result_bits[:-(null_count*8)]
                found_end = True; break
        else:
            null_count = 0
    if not found_end:
        print("[WARNING] Delimiter not found - image may not contain hidden data")
    message = bits_to_text(result_bits)
    print(f"[OK] Extracted message: '{message}'")
    print(f"[OK] Length: {len(message)} characters")
    if output_path:
        os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(message + '\n')
        print(f"[OK] Saved to: {output_path}")
    return message

def main():
    parser = argparse.ArgumentParser(description='LSB Extract - Reveal message from PNG')
    parser.add_argument('--input',  '-i', required=True)
    parser.add_argument('--output', '-o', default=None)
    args = parser.parse_args()
    print("="*55)
    print("  LSB STEGANOGRAPHY - EXTRACT")
    print("="*55)
    extract_message(args.input, args.output)
    print("="*55)

if __name__ == '__main__':
    main()
PYEOF

# -------- chi_square_test.py --------
cat > "$LAB_DIR/receiver/steg_lab/chi_square_test.py" << 'PYEOF'
#!/usr/bin/env python3
"""Chi-Square Attack - Statistical detection of LSB steganography"""
import sys, os, argparse, math
try:
    from PIL import Image
except ImportError:
    os.system("pip3 install Pillow --break-system-packages 2>/dev/null || pip3 install Pillow")
    from PIL import Image

def normal_cdf(x):
    t = 1.0/(1.0+0.2316419*abs(x))
    p = t*(0.319381530+t*(-0.356563782+t*(1.781477937+t*(-1.821255978+t*1.330274429))))
    cdf = 1.0-(1.0/math.sqrt(2*math.pi))*math.exp(-0.5*x*x)*p
    return (1.0-cdf) if x < 0 else cdf

def chi2_pvalue(chi2, df):
    if chi2 <= 0: return 1.0
    if df <= 0: return 0.0
    h = 2.0/(9.0*df)
    z = (pow(chi2/df, 1.0/3.0) - (1-h)) / math.sqrt(max(h, 1e-10))
    return 1.0 - normal_cdf(z)

def chi_square_attack(image_path, ch=0):
    img = Image.open(image_path)
    if img.mode != 'RGB': img = img.convert('RGB')
    pixels = list(img.getdata())
    freq = [0]*256
    for px in pixels: freq[px[ch]] += 1
    chi2, df = 0.0, 0
    for k in range(128):
        n0, n1 = freq[2*k], freq[2*k+1]
        if n0+n1 == 0: continue
        exp = (n0+n1)/2.0
        chi2 += (n0-exp)**2/exp + (n1-exp)**2/exp
        df += 1
    return chi2, chi2_pvalue(chi2, df) if df > 0 else 1.0, df

def analyze_image(image_path):
    print(f"\n{'='*60}")
    print(f"  CHI-SQUARE ATTACK - LSB STEGANALYSIS")
    print(f"{'='*60}")
    print(f"  File: {image_path}")
    try:
        img = Image.open(image_path)
        w, h = img.size
        fsize = os.path.getsize(image_path)
        print(f"  Size: {w}x{h} | File: {fsize:,} bytes")
    except Exception as e:
        print(f"  [ERROR] {e}"); return None
    print(f"\n  {'Channel':<10} {'Chi2':>12} {'DF':>8} {'p-value':>12}  Verdict")
    print(f"  {'-'*55}")
    channels = ['R (Red)', 'G (Green)', 'B (Blue)']
    pvals = []
    for ci, cn in enumerate(channels):
        chi2, pv, df = chi_square_attack(image_path, ci)
        pvals.append(pv)
        v = "⚠ LIKELY HIDDEN DATA" if pv > 0.05 else ("? UNCERTAIN" if pv > 0.01 else "✓ CLEAN")
        print(f"  {cn:<10} {chi2:>12.2f} {df:>8d} {pv:>12.6f}  {v}")
    avg = sum(pvals)/len(pvals)
    print(f"  {'-'*55}")
    verdict = "⚠ HIGH PROBABILITY - STEGO DETECTED" if avg > 0.05 else ("? LOW PROBABILITY" if avg > 0.01 else "✓ IMAGE APPEARS CLEAN")
    print(f"  {'Average':<10} {'':>12} {'':>8} {avg:>12.6f}  {verdict}")
    print(f"\n  Interpretation:")
    print(f"  p-value > 0.05 → LSBs appear random → Steganography LIKELY")
    print(f"  p-value < 0.05 → LSBs appear natural → Image CLEAN")
    print(f"\n  [RECORD THESE VALUES]")
    print(f"  avg_pvalue={avg:.6f}")
    for i,n in enumerate(['R','G','B']): print(f"  {n}_pvalue={pvals[i]:.6f}")
    print(f"{'='*60}\n")
    return avg

def main():
    parser = argparse.ArgumentParser(description='Chi-Square Attack on PNG')
    parser.add_argument('--image','-i', required=True)
    args = parser.parse_args()
    analyze_image(args.image)

if __name__ == '__main__':
    main()
PYEOF

# Copy shared scripts
cp "$LAB_DIR/receiver/steg_lab/lsb_extract.py"   "$LAB_DIR/sender/steg_lab/lsb_extract.py"
cp "$LAB_DIR/receiver/steg_lab/chi_square_test.py" "$LAB_DIR/sender/steg_lab/chi_square_test.py"
cp "$LAB_DIR/sender/steg_lab/lsb_embed.py"        "$LAB_DIR/receiver/steg_lab/lsb_embed.py"
cp "$LAB_DIR/sender/steg_lab/generate_cover.py"   "$LAB_DIR/receiver/steg_lab/generate_cover.py"

echo "[4/5] Tạo startup scripts..."

# sender bin
cat > "$LAB_DIR/sender/bin/sender_start.sh" << 'SHEOF'
#!/bin/bash
LAB_DIR="/root/steg_lab"
echo "====================================="
echo " T-STEG01: LSB Stego Lab - SENDER"
echo "====================================="
mkdir -p "$LAB_DIR"
python3 -c "from PIL import Image" 2>/dev/null || pip3 install Pillow --break-system-packages 2>/dev/null
[ ! -f "$LAB_DIR/cover_image.png" ] && python3 "$LAB_DIR/generate_cover.py" "$LAB_DIR/cover_image.png"
mkdir -p ~/.ssh
cat > ~/.ssh/config << 'SSH'
Host *
    StrictHostKeyChecking no
    UserKnownHostsFile /dev/null
    LogLevel ERROR
SSH
chmod 600 ~/.ssh/config
echo "[OK] Sender ready. Files:"; ls -la "$LAB_DIR/"
SHEOF

# receiver bin
cat > "$LAB_DIR/receiver/bin/receiver_start.sh" << 'SHEOF'
#!/bin/bash
LAB_DIR="/root/steg_lab"
echo "======================================="
echo " T-STEG01: LSB Stego Lab - RECEIVER"
echo "======================================="
mkdir -p "$LAB_DIR"
python3 -c "from PIL import Image" 2>/dev/null || pip3 install Pillow --break-system-packages 2>/dev/null
mkdir -p /var/run/sshd && ssh-keygen -A 2>/dev/null
echo 'root:receiver123' | chpasswd 2>/dev/null
sed -i 's/.*PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config 2>/dev/null
/usr/sbin/sshd 2>/dev/null || true
echo "[OK] Receiver ready. SSH password: receiver123"
echo "[OK] Waiting for stego_image.png..."
SHEOF

chmod +x "$LAB_DIR/sender/bin/sender_start.sh"
chmod +x "$LAB_DIR/receiver/bin/receiver_start.sh"
chmod +x "$LAB_DIR/sender/steg_lab/"*.py
chmod +x "$LAB_DIR/receiver/steg_lab/"*.py

echo "[5/5] Tạo Dockerfile..."

cat > "$LAB_DIR/sender/Dockerfile" << 'DFEOF'
FROM mfthomps/labtainers.base
RUN apt-get update -qq && apt-get install -y python3 python3-pip openssh-client iputils-ping --no-install-recommends \
    && rm -rf /var/lib/apt/lists/*
RUN pip3 install Pillow --break-system-packages 2>/dev/null || pip3 install Pillow
RUN mkdir -p /root/steg_lab /root/bin
COPY steg_lab/ /root/steg_lab/
COPY bin/ /root/bin/
RUN chmod +x /root/bin/*.sh /root/steg_lab/*.py
CMD ["/bin/bash", "-c", "/root/bin/sender_start.sh && bash"]
DFEOF

cat > "$LAB_DIR/receiver/Dockerfile" << 'DFEOF'
FROM mfthomps/labtainers.base
RUN apt-get update -qq && apt-get install -y python3 python3-pip openssh-server iputils-ping --no-install-recommends \
    && rm -rf /var/lib/apt/lists/*
RUN pip3 install Pillow --break-system-packages 2>/dev/null || pip3 install Pillow
RUN mkdir -p /root/steg_lab /root/bin /var/run/sshd
COPY steg_lab/ /root/steg_lab/
COPY bin/ /root/bin/
RUN chmod +x /root/bin/*.sh /root/steg_lab/*.py
CMD ["/bin/bash", "-c", "/root/bin/receiver_start.sh && bash"]
DFEOF

echo ""
echo "============================================================"
echo "  CÀI ĐẶT HOÀN TẤT!"
echo ""
echo "  Lab đã được cài tại: $LAB_DIR"
echo ""
echo "  Để chạy lab:"
echo "    labtainer $LAB_NAME"
echo ""
echo "  Để xóa và cài lại:"
echo "    bash $0"
echo "============================================================"
