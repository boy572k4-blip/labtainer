#!/bin/bash
# fixlocal.sh - Chạy tự động bởi Labtainer framework khi container receiver khởi động.

mkdir -p /root/steg_lab

mkdir -p /root/.ssh
cat > /root/.ssh/config << 'SSHEOF'
Host *
    StrictHostKeyChecking no
    UserKnownHostsFile /dev/null
    LogLevel ERROR
SSHEOF
chmod 700 /root/.ssh
chmod 600 /root/.ssh/config

echo ""
echo "=========================================="
echo "  LAB T-STEG01: LSB Steganography"
echo "  MAY: RECEIVER  IP: 172.21.0.30"
echo "=========================================="
echo "  Thu muc lab : ~/steg_lab/"
echo ""
echo "  Bat dau bang lenh:"
echo "    ls ~/steg_lab/"
echo "=========================================="
