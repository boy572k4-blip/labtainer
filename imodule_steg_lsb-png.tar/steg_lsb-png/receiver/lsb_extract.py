#!/usr/bin/env python3
"""
lsb_extract.py - Trích xuất thông điệp bí mật từ ảnh stego PNG.

Sử dụng:
    python3 lsb_extract.py --image stego_image.png
"""
import argparse
import sys
import os
from PIL import Image

DELIMITER = "<<<END>>>"

def bits_to_text(bits):
    chars = []
    for i in range(0, len(bits) - 7, 8):
        byte = bits[i:i+8]
        char = chr(int(byte, 2))
        chars.append(char)
    return ''.join(chars)

def extract_message(image_path):
    try:
        img = Image.open(image_path)
    except FileNotFoundError:
        print("[!] Loi: Khong tim thay file '{}'".format(image_path))
        sys.exit(1)

    if img.mode != 'RGB':
        img = img.convert('RGB')

    pixels = list(img.getdata())
    bits = ""

    for pixel in pixels:
        for val in pixel:
            bits += str(val & 1)

    text = bits_to_text(bits)

    if DELIMITER in text:
        message = text[:text.index(DELIMITER)]
        return message
    else:
        return None

def main():
    parser = argparse.ArgumentParser(description='LSB Extract - Trich xuat thong diep tu anh PNG')
    parser.add_argument('--image', required=True, help='Anh stego can trich xuat')
    args = parser.parse_args()

    print("[*] Dang trich xuat tu: {}".format(args.image))
    message = extract_message(args.image)

    out_dir = "/root/steg_lab"
    os.makedirs(out_dir, exist_ok=True)

    if message:
        print("[+] Thong diep trich xuat duoc: '{}'".format(message))
        # Luu extracted_message.txt
        with open(os.path.join(out_dir, "extracted_message.txt"), "w") as f:
            f.write(message + "\n")
        # Luu result.txt (dung de chấm điểm)
        with open(os.path.join(out_dir, "result.txt"), "w") as f:
            f.write("message={}\n".format(message))
        print("[+] Da luu ket qua vao {}/result.txt".format(out_dir))
    else:
        print("[!] Khong tim thay thong diep an trong anh nay.")
        with open(os.path.join(out_dir, "result.txt"), "w") as f:
            f.write("message=NOT_FOUND\n")

if __name__ == "__main__":
    main()
