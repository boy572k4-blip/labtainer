#!/usr/bin/env python3
"""
chi_square_test.py - Chi-Square Attack để phát hiện dữ liệu ẩn trong ảnh PNG.
"""
import argparse
import sys
import os
import numpy as np
from PIL import Image

try:
    from scipy.stats import chisquare
    HAS_SCIPY = True
except ImportError:
    HAS_SCIPY = False

def chi_square_attack(image_path):
    try:
        img = Image.open(image_path)
    except FileNotFoundError:
        print("[!] Loi: Khong tim thay file '{}'".format(image_path))
        sys.exit(1)

    if img.mode != 'RGB':
        img = img.convert('RGB')

    data = np.array(img)
    channel = data[:, :, 0].flatten()
    freq = np.bincount(channel, minlength=256)

    observed = []
    expected = []
    for i in range(0, 255, 2):
        total = freq[i] + freq[i+1]
        exp = total / 2.0
        if exp > 0:
            observed.append(float(freq[i]))
            expected.append(exp)

    observed = np.array(observed)
    expected = np.array(expected)

    if HAS_SCIPY:
        chi2, pval = chisquare(observed, f_exp=expected)
    else:
        chi2 = float(np.sum((observed - expected)**2 / (expected + 1e-10)))
        df = max(len(observed) - 1, 1)
        pval = float(np.exp(-chi2 / (2.0 * df)))

    return chi2, pval

def interpret(pval):
    if pval < 0.001:
        return "RAT CO KHA NANG chua du lieu an (p < 0.001)"
    elif pval < 0.05:
        return "CO KHA NANG chua du lieu an (p < 0.05)"
    elif pval < 0.1:
        return "NGHI NGO - can phan tich them (p < 0.1)"
    else:
        return "KHONG phat hien du lieu an (p >= 0.1)"

def main():
    parser = argparse.ArgumentParser(description='Chi-Square Attack')
    parser.add_argument('--image', required=True, help='Anh can phan tich')
    args = parser.parse_args()

    chi2, pval = chi_square_attack(args.image)
    result_str = interpret(pval)

    print("=" * 54)
    print("  CHI-SQUARE ATTACK - PHAT HIEN STEGANOGRAPHY")
    print("=" * 54)
    print("  Chi2 statistic : {:.4f}".format(chi2))
    print("  p-value        : {:.6f}".format(pval))
    print("  Ket qua        : {}".format(result_str))
    print("=" * 54)

    out_dir = "/root/steg_lab"
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, "chi_square_result.txt"), "w") as f:
        f.write("chi2={:.4f}\n".format(chi2))
        f.write("pvalue={:.6f}\n".format(pval))
        f.write("result={}\n".format(result_str))

if __name__ == "__main__":
    main()
