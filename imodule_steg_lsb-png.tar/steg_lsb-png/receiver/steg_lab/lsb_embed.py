#!/usr/bin/env python3
"""
lsb_embed.py – Nhúng thông điệp bí mật vào ảnh PNG bằng kỹ thuật LSB.

Cách dùng:
    python3 lsb_embed.py --input cover_image.png --output stego_image.png --message "HELLO"
"""

import argparse
import sys
from PIL import Image


DELIMITER = "<<<END>>>"


def text_to_bits(text: str) -> str:
    """Chuyển chuỗi văn bản thành chuỗi bit nhị phân."""
    result = ""
    for char in text:
        bits = format(ord(char), '08b')
        result += bits
    return result


def embed_message(input_path: str, output_path: str, message: str) -> None:
    """Nhúng thông điệp vào ảnh PNG bằng LSB."""
    img = Image.open(input_path)
    if img.mode != 'RGB':
        img = img.convert('RGB')

    pixels = list(img.getdata())
    width, height = img.size

    # Thêm delimiter để biết khi nào dừng trích xuất
    full_message = message + DELIMITER
    bits = text_to_bits(full_message)

    max_bits = width * height * 3
    if len(bits) > max_bits:
        print(f"[!] Lỗi: Thông điệp quá dài! Tối đa {max_bits // 8} ký tự.")
        sys.exit(1)

    print(f"[+] Ảnh gốc: {input_path} ({width}x{height})")
    print(f"[+] Thông điệp: '{message}' ({len(message)} ký tự)")
    print(f"[+] Số bit cần nhúng: {len(bits)} / {max_bits} bits tối đa")

    new_pixels = []
    bit_index = 0

    for pixel in pixels:
        r, g, b = pixel
        channels = [r, g, b]
        new_channels = []

        for channel_val in channels:
            if bit_index < len(bits):
                # Thay thế LSB của channel bằng bit thông điệp
                new_val = (channel_val & 0xFE) | int(bits[bit_index])
                new_channels.append(new_val)
                bit_index += 1
            else:
                new_channels.append(channel_val)

        new_pixels.append(tuple(new_channels))

    new_img = Image.new('RGB', (width, height))
    new_img.putdata(new_pixels)
    new_img.save(output_path, 'PNG')

    print(f"[+] Đã nhúng thành công! Ảnh stego: {output_path}")
    print(f"[+] Tỉ lệ sử dụng: {len(bits)/max_bits*100:.2f}%")


def main():
    parser = argparse.ArgumentParser(
        description='LSB Steganography - Nhúng thông điệp vào ảnh PNG'
    )
    parser.add_argument('--input',   required=True, help='Đường dẫn ảnh gốc (cover image)')
    parser.add_argument('--output',  required=True, help='Đường dẫn ảnh đầu ra (stego image)')
    parser.add_argument('--message', required=True, help='Thông điệp bí mật cần nhúng')
    args = parser.parse_args()

    embed_message(args.input, args.output, args.message)


if __name__ == "__main__":
    main()
