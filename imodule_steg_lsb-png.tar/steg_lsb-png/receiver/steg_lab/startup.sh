#!/bin/bash
# startup.sh – Chạy khi container receiver khởi động

echo "[*] Đang chuẩn bị môi trường lab steganography (receiver)..."

# Tạo thư mục nếu chưa có
mkdir -p /root/steg_lab

# Cấu hình SSH
mkdir -p /root/.ssh
cat > /root/.ssh/config << 'EOF'
Host *
    StrictHostKeyChecking no
    UserKnownHostsFile /dev/null
EOF
chmod 600 /root/.ssh/config

# Khởi động SSH daemon
service ssh start 2>/dev/null || true

echo ""
echo "==========================================="
echo "  LAB T-STEG01: LSB Steganography"
echo "  Máy: RECEIVER (172.21.0.30)"
echo "==========================================="
echo ""
echo "  Thư mục lab: ~/steg_lab/"
echo "  Chờ nhận ảnh stego từ sender..."
echo ""
echo "  Sau khi nhận ảnh, chạy:"
echo "  python3 ~/steg_lab/lsb_extract.py \\"
echo "      --input ~/steg_lab/stego_image.png \\"
echo "      --output ~/steg_lab/extracted_message.txt"
echo "==========================================="
