#!/usr/bin/env python3
"""
chi_square_test.py – Phân tích thống kê Chi-Square để phát hiện steganography.

Kỹ thuật Chi-Square Attack phân tích phân phối tần suất của các cặp giá trị màu
(value, value+1) – còn gọi là PoVs (Pairs of Values). Nếu ảnh chứa dữ liệu LSB,
tần suất của các cặp này sẽ trở nên đều nhau bất thường, dẫn đến p-value thấp.

Cách dùng:
    python3 chi_square_test.py --image stego_image.png
"""

import argparse
import sys
import numpy as np
from PIL import Image

try:
    from scipy.stats import chisquare
    HAS_SCIPY = True
except ImportError:
    HAS_SCIPY = False


def chi_square_attack(image_path: str) -> float:
    """
    Thực hiện Chi-Square Attack trên kênh màu R của ảnh.
    Trả về p-value: giá trị càng thấp → khả năng chứa dữ liệu ẩn càng cao.
    """
    img = Image.open(image_path)
    if img.mode != 'RGB':
        img = img.convert('RGB')

    data = np.array(img)
    # Phân tích kênh Red
    channel = data[:, :, 0].flatten()

    # Đếm tần suất xuất hiện của từng giá trị 0–255
    freq = np.bincount(channel, minlength=256)

    # Chi-Square trên các cặp PoV: (0,1), (2,3), (4,5), ..., (254,255)
    observed = []
    expected = []
    for i in range(0, 255, 2):
        obs_pair = freq[i] + freq[i+1]
        exp_each = obs_pair / 2.0
        if exp_each > 0:
            observed.append(freq[i])
            expected.append(exp_each)

    observed = np.array(observed, dtype=float)
    expected = np.array(expected, dtype=float)

    if HAS_SCIPY:
        chi2_stat, p_value = chisquare(observed, f_exp=expected)
    else:
        # Tính thủ công nếu không có scipy
        chi2_stat = np.sum((observed - expected) ** 2 / (expected + 1e-10))
        # Xấp xỉ p-value đơn giản (không chính xác hoàn toàn)
        df = len(observed) - 1
        p_value = float(np.exp(-chi2_stat / (2 * df)))

    return chi2_stat, p_value


def interpret_result(p_value: float) -> str:
    """Diễn giải kết quả p-value."""
    if p_value < 0.001:
        return "RẤT CÓ KHẢ NĂNG chứa dữ liệu ẩn (p < 0.001)"
    elif p_value < 0.05:
        return "CÓ KHẢ NĂNG chứa dữ liệu ẩn (p < 0.05)"
    elif p_value < 0.1:
        return "NGHI NGỜ – cần phân tích thêm (0.05 ≤ p < 0.1)"
    else:
        return "KHÔNG phát hiện dữ liệu ẩn (p ≥ 0.1)"


def main():
    parser = argparse.ArgumentParser(
        description='Chi-Square Attack – Phân tích ảnh PNG để phát hiện steganography'
    )
    parser.add_argument('--image', required=True, help='Đường dẫn ảnh cần phân tích')
    args = parser.parse_args()

    print("=" * 55)
    print("    CHI-SQUARE ATTACK – PHÂN TÍCH STEGANOGRAPHY")
    print("=" * 55)
    print(f"[*] Đang phân tích: {args.image}")

    try:
        chi2, p_value = chi_square_attack(args.image)
    except FileNotFoundError:
        print(f"[!] Lỗi: Không tìm thấy file '{args.image}'")
        sys.exit(1)
    except Exception as e:
        print(f"[!] Lỗi khi phân tích ảnh: {e}")
        sys.exit(1)

    print(f"\n  Chi² statistic : {chi2:.4f}")
    print(f"  p-value        : {p_value:.6f}")
    print(f"\n  Kết quả: {interpret_result(p_value)}")
    print("\n  Giải thích:")
    print("  - p-value THẤP  → phân phối LSB bất thường → CÓ dữ liệu ẩn")
    print("  - p-value CAO   → phân phối LSB tự nhiên   → KHÔNG có dữ liệu ẩn")
    print("=" * 55)

    return p_value


if __name__ == "__main__":
    main()
