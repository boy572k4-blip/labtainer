#!/usr/bin/env python3
"""
chi_square_test.py - Phân tích thống kê Chi-Square Attack để phát hiện LSB steganography

Nguyên lý:
  - Ảnh bình thường: các cặp giá trị màu (2k, 2k+1) có phân phối tự nhiên.
    Ví dụ: số pixel có R=100 và số pixel có R=101 thường KHÁC NHAU.
  - Ảnh đã nhúng LSB: LSB bị ghi đè → các cặp (2k, 2k+1) trở nên CÂN BẰNG hơn.
    Ví dụ: số pixel R=100 ≈ số pixel R=101.
  - Chi-Square test đo sự sai lệch này:
    - p-value cao (>0.05): ảnh có vẻ đã bị nhúng dữ liệu
    - p-value thấp (<0.05): ảnh bình thường

Tham chiếu: Westfeld & Pfitzmann, 2000 - "Attacks on Steganographic Systems"
"""

import sys
import os
import argparse
import math

try:
    from PIL import Image
except ImportError:
    os.system("pip3 install Pillow --break-system-packages 2>/dev/null || pip3 install Pillow")
    from PIL import Image


def chi_square_cdf(chi2, df):
    """Tính CDF của phân phối chi-square (xấp xỉ bằng gamma incomplete)"""
    # Sử dụng xấp xỉ Wilson-Hilferty
    if chi2 <= 0:
        return 0.0
    if df <= 0:
        return 1.0

    # Regularized incomplete gamma function (xấp xỉ đơn giản)
    # P(x, a) ≈ xấp xỉ bằng chuỗi Taylor
    x = chi2 / 2.0
    a = df / 2.0

    # Sử dụng phương pháp series expansion cho giá trị nhỏ
    if x < a + 1:
        # Series expansion
        term = 1.0 / a
        total = term
        n = a
        for _ in range(200):
            n += 1
            term *= x / n
            total += term
            if term < 1e-10:
                break
        # Gamma function (Stirling approximation)
        log_gamma_a = (a - 0.5) * math.log(a) - a + 0.5 * math.log(2 * math.pi) if a > 0.5 else 0
        gamma_a = math.exp(log_gamma_a) if a > 0.5 else 1.0
        result = math.exp(-x + a * math.log(x) - math.log(gamma_a if gamma_a > 0 else 1)) * total
        return min(1.0, max(0.0, result))
    else:
        # Complement (upper tail) - xấp xỉ Wilson-Hilferty
        h = 2.0 / (9.0 * df)
        z = (math.pow(chi2 / df, 1.0/3.0) - (1 - h)) / math.sqrt(h)
        # Normal CDF approximation
        return 1.0 - normal_cdf(z)


def normal_cdf(x):
    """Xấp xỉ CDF của phân phối chuẩn"""
    # Abramowitz & Stegun approximation
    t = 1.0 / (1.0 + 0.2316419 * abs(x))
    p = t * (0.319381530 + t * (-0.356563782 + t * (1.781477937 + t * (-1.821255978 + t * 1.330274429))))
    cdf = 1.0 - (1.0 / math.sqrt(2 * math.pi)) * math.exp(-0.5 * x * x) * p
    if x < 0:
        return 1.0 - cdf
    return cdf


def chi_square_attack(image_path, channel_index=0):
    """
    Thực hiện Chi-Square Attack trên một kênh màu của ảnh
    channel_index: 0=R, 1=G, 2=B
    """
    try:
        img = Image.open(image_path)
    except FileNotFoundError:
        print(f"[ERROR] Không tìm thấy ảnh: {image_path}")
        sys.exit(1)

    if img.mode != 'RGB':
        img = img.convert('RGB')

    pixels = [img.getpixel((x,y)) for y in range(img.size[1]) for x in range(img.size[0])]
    channel_names = ['R (Red)', 'G (Green)', 'B (Blue)']

    # Đếm tần suất từng giá trị trong kênh màu
    freq = [0] * 256
    for pixel in pixels:
        freq[pixel[channel_index]] += 1

    # Chi-Square test trên các cặp (2k, 2k+1)
    chi2 = 0.0
    degrees_of_freedom = 0
    pairs_info = []

    for k in range(0, 128):
        n0 = freq[2 * k]      # tần suất giá trị chẵn
        n1 = freq[2 * k + 1]  # tần suất giá trị lẻ

        if n0 + n1 == 0:
            continue

        expected = (n0 + n1) / 2.0

        if expected > 0:
            chi2 += ((n0 - expected) ** 2) / expected
            chi2 += ((n1 - expected) ** 2) / expected
            degrees_of_freedom += 1
            if k < 5:  # Chỉ hiển thị 5 cặp đầu
                pairs_info.append((2*k, 2*k+1, n0, n1, expected))

    if degrees_of_freedom == 0:
        return 0.0, 0.0, 0

    # Tính p-value
    p_value = 1.0 - chi_square_cdf(chi2, degrees_of_freedom)

    return chi2, p_value, degrees_of_freedom


def analyze_image(image_path):
    """Phân tích toàn diện một ảnh PNG"""
    print(f"\n{'='*65}")
    print(f"  CHI-SQUARE ATTACK - PHÂN TÍCH STEGANOGRAPHY")
    print(f"{'='*65}")
    print(f"  Ảnh: {image_path}")

    try:
        img = Image.open(image_path)
        w, h = img.size
        print(f"  Kích thước: {w}x{h} | Mode: {img.mode}")
        file_size = os.path.getsize(image_path)
        print(f"  Dung lượng file: {file_size:,} bytes")
    except Exception as e:
        print(f"  [ERROR] {e}")
        return None

    print(f"\n{'─'*65}")
    print(f"  {'Kênh':<10} {'Chi² value':>14} {'Bậc tự do':>12} {'p-value':>12}  Kết quả")
    print(f"{'─'*65}")

    channel_names = ['R (Red)', 'G (Green)', 'B (Blue)']
    p_values = []

    for ch_idx, ch_name in enumerate(channel_names):
        chi2, p_val, df = chi_square_attack(image_path, ch_idx)
        p_values.append(p_val)

        # Đánh giá
        if p_val > 0.05:
            verdict = "⚠  CÓ THỂ CÓ DỮ LIỆU ẨN"
            flag = "!"
        elif p_val > 0.01:
            verdict = "?  KHẢ NĂNG THẤP"
            flag = "?"
        else:
            verdict = "✓  BÌNH THƯỜNG"
            flag = " "

        print(f"  {ch_name:<10} {chi2:>14.2f} {df:>12d} {p_val:>12.6f}  {verdict}")

    avg_p = sum(p_values) / len(p_values)
    print(f"{'─'*65}")
    print(f"  {'Trung bình':<10} {'':>14} {'':>12} {avg_p:>12.6f}  ", end='')

    if avg_p > 0.05:
        print("⚠  KHẢ NĂNG CAO CÓ DỮ LIỆU ẨN")
    elif avg_p > 0.01:
        print("?  KHẢ NĂNG THẤP")
    else:
        print("✓  ẢNH SẠCH")

    print(f"\n  Giải thích:")
    print(f"  • p-value > 0.05 → LSB gần như ngẫu nhiên → CÓ THỂ bị nhúng dữ liệu")
    print(f"  • p-value < 0.05 → LSB phân phối tự nhiên → Ảnh bình thường")
    print(f"{'='*65}\n")

    # In p-value để sinh viên ghi lại
    print(f"[KẾT QUẢ ĐỂ GHI VÀO FILE]")
    print(f"  avg_pvalue={avg_p:.6f}")
    print(f"  R_pvalue={p_values[0]:.6f}")
    print(f"  G_pvalue={p_values[1]:.6f}")
    print(f"  B_pvalue={p_values[2]:.6f}\n")

    return avg_p


def main():
    parser = argparse.ArgumentParser(
        description='Chi-Square Attack - Phát hiện LSB Steganography',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Ví dụ:
  python3 chi_square_test.py --image stego.png
  python3 chi_square_test.py --image cover.png
  
Giải thích kết quả:
  p-value cao (> 0.05): LSB gần như ngẫu nhiên → KHẢ NĂNG CAO có dữ liệu ẩn
  p-value thấp (< 0.05): LSB phân phối tự nhiên → ảnh bình thường
        """
    )
    parser.add_argument('--image', '-i', required=True, help='Đường dẫn ảnh PNG cần phân tích')

    args = parser.parse_args()
    analyze_image(args.image)


if __name__ == '__main__':
    main()
