#!/usr/bin/env python3
"""Chi-Square Attack - Phát hiện LSB Steganography"""
import argparse
from PIL import Image
from scipy import stats
import numpy as np

def chi_square_attack(image_path):
    img = Image.open(image_path).convert('RGB')
    pixels = np.array(img).flatten()
    print(f"\n[CHI-SQUARE ATTACK] Phân tích: {image_path}")
    print(f"[INFO] Kích thước: {img.size[0]}x{img.size[1]} | Tổng channels: {len(pixels)}")

    observed, _ = np.histogram(pixels, bins=256, range=(0, 256))
    chi2_stat = 0.0
    pairs_used = 0
    for k in range(128):
        o1, o2 = observed[2*k], observed[2*k+1]
        expected = (o1 + o2) / 2.0
        if expected > 0:
            chi2_stat += ((o1-expected)**2 + (o2-expected)**2) / expected
            pairs_used += 1

    dof = pairs_used - 1
    p_value = 1 - stats.chi2.cdf(chi2_stat, df=dof)

    print(f"\n[RESULT] Chi-Square Statistic : {chi2_stat:.4f}")
    print(f"[RESULT] Degrees of Freedom   : {dof}")
    print(f"[RESULT] P-value              : {p_value:.6f}")
    print("\n[PHÂN TÍCH]")
    if p_value < 0.05:
        print("  => p-value < 0.05: Phân phối LSB BẤT THƯỜNG → CÓ dữ liệu ẩn!")
    else:
        print("  => p-value >= 0.05: Phân phối tự nhiên → KHÔNG có dữ liệu ẩn.")
    print(f"\n[OUTPUT] p_value={p_value:.6f}")
    return p_value

def main():
    parser = argparse.ArgumentParser(description='Chi-Square Attack')
    parser.add_argument('--image', required=True)
    args = parser.parse_args()
    chi_square_attack(args.image)

if __name__ == '__main__':
    main()
