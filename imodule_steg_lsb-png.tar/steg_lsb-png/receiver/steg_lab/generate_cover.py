#!/usr/bin/env python3
"""
Script tạo ảnh cover_image.png cho bài lab steganography.
Chạy script này một lần để tạo ảnh PNG dùng làm ảnh gốc.
"""
from PIL import Image
import numpy as np
import random

def generate_cover_image(output_path="cover_image.png", width=512, height=512):
    """Tạo ảnh PNG với nội dung đơn giản (gradient + noise tự nhiên)."""
    random.seed(42)
    np.random.seed(42)

    # Tạo ảnh gradient màu sắc tự nhiên
    img_array = np.zeros((height, width, 3), dtype=np.uint8)

    for y in range(height):
        for x in range(width):
            # Gradient cơ bản
            r = int((x / width) * 200 + 30)
            g = int((y / height) * 200 + 30)
            b = int(((x + y) / (width + height)) * 180 + 50)

            # Thêm noise nhỏ để ảnh tự nhiên hơn
            r = min(255, max(0, r + random.randint(-15, 15)))
            g = min(255, max(0, g + random.randint(-15, 15)))
            b = min(255, max(0, b + random.randint(-15, 15)))

            img_array[y, x] = [r, g, b]

    img = Image.fromarray(img_array, 'RGB')
    img.save(output_path, 'PNG')
    print(f"[+] Đã tạo ảnh cover: {output_path}")
    print(f"    Kích thước: {width}x{height} pixels")
    print(f"    Mode: RGB")
    print(f"    Dung lượng nhúng tối đa: {(width * height * 3) // 8} bytes")

if __name__ == "__main__":
    import os
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cover_image.png")
    generate_cover_image(out)
