#!/usr/bin/env python3
"""LSB Steganography - Trích xuất thông điệp từ ảnh PNG"""
import argparse
from PIL import Image
import sys

DELIMITER = "<<END>>"

def extract_message(input_path, output_path):
    img = Image.open(input_path).convert('RGB')
    pixels = list(img.getdata())
    width, height = img.size
    print(f"[INFO] Phân tích ảnh: {width}x{height} pixels")

    bits = []
    for r, g, b in pixels:
        bits.extend([r & 1, g & 1, b & 1])

    text = ""
    for i in range(0, len(bits) - 7, 8):
        byte = 0
        for j in range(8):
            byte = (byte << 1) | bits[i + j]
        if byte == 0:
            break
        text += chr(byte)
        if text.endswith(DELIMITER):
            message = text[:-len(DELIMITER)]
            print(f"[SUCCESS] Thông điệp: '{message}'")
            with open(output_path, 'w') as f:
                f.write(message + '\n')
            print(f"[INFO] Lưu vào: {output_path}")
            return

    print("[WARNING] Không tìm thấy thông điệp ẩn.")
    sys.exit(1)

def main():
    parser = argparse.ArgumentParser(description='LSB Extract')
    parser.add_argument('--input',  required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    extract_message(args.input, args.output)

if __name__ == '__main__':
    main()
