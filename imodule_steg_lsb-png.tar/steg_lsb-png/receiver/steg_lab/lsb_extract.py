#!/usr/bin/env python3
"""
lsb_extract.py – Trích xuất thông điệp ẩn từ ảnh PNG đã nhúng bằng LSB.

Cách dùng:
    python3 lsb_extract.py --input stego_image.png --output extracted_message.txt
"""

import argparse
import sys
from PIL import Image


DELIMITER = "<<<END>>>"


def bits_to_text(bits: str) -> str:
    """Chuyển chuỗi bit nhị phân về văn bản."""
    chars = []
    for i in range(0, len(bits), 8):
        byte = bits[i:i+8]
        if len(byte) < 8:
            break
        char_code = int(byte, 2)
        if 0 < char_code < 128:
            chars.append(chr(char_code))
        else:
            chars.append('?')
    return "".join(chars)


def extract_message(input_path: str, output_path: str) -> str:
    """Trích xuất thông điệp ẩn từ ảnh PNG."""
    img = Image.open(input_path)
    if img.mode != 'RGB':
        img = img.convert('RGB')

    pixels = list(img.getdata())
    width, height = img.size

    print(f"[+] Đang phân tích ảnh: {input_path} ({width}x{height})")

    # Thu thập tất cả LSB từ các kênh màu
    bits = ""
    for pixel in pixels:
        for channel_val in pixel[:3]:  # R, G, B
            bits += str(channel_val & 1)

    # Giải mã từng 8 bit một, tìm delimiter
    message = ""
    i = 0
    while i + 8 <= len(bits):
        byte_bits = bits[i:i+8]
        char_code = int(byte_bits, 2)
        if 0 < char_code < 128:
            char = chr(char_code)
            message += char
            # Kiểm tra nếu tìm thấy delimiter
            if message.endswith(DELIMITER):
                message = message[:-len(DELIMITER)]
                break
        i += 8

    if not message:
        print("[!] Không tìm thấy thông điệp ẩn trong ảnh này.")
        sys.exit(1)

    print(f"[+] Trích xuất thành công! Thông điệp: '{message}'")
    print(f"[+] Độ dài: {len(message)} ký tự")

    with open(output_path, 'w') as f:
        f.write(message + "\n")
    print(f"[+] Đã lưu vào: {output_path}")

    return message


def main():
    parser = argparse.ArgumentParser(
        description='LSB Steganography - Trích xuất thông điệp từ ảnh PNG'
    )
    parser.add_argument('--input',  required=True, help='Đường dẫn ảnh stego')
    parser.add_argument('--output', required=True, help='File lưu thông điệp trích xuất')
    args = parser.parse_args()

    extract_message(args.input, args.output)


if __name__ == "__main__":
    main()
