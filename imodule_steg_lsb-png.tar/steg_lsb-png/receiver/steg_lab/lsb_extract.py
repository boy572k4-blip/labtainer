#!/usr/bin/env python3
"""LSB Steganography - Extract message from PNG"""
import sys, os, argparse
from PIL import Image

def extract_message(stego_path, output_path=None):
    img = Image.open(stego_path)
    if img.mode != 'RGB': img = img.convert('RGB')
    width, height = img.size
    pixels = list(img.getdata())
    print(f"[INFO] Analyzing: {stego_path} ({width}x{height})")

    bits = []
    for pixel in pixels:
        bits.extend([pixel[0]&1, pixel[1]&1, pixel[2]&1])

    # Ghép thành chuỗi ký tự, dừng tại null byte
    chars = []
    for i in range(0, len(bits)-7, 8):
        bv = sum(bits[i+j] << (7-j) for j in range(8))
        if bv == 0:
            break
        if 32 <= bv <= 126:
            chars.append(chr(bv))
        else:
            chars.append('?')

    raw = ''.join(chars)

    # Cắt tại delimiter <<END>> nếu có
    if '<<END>>' in raw:
        message = raw.split('<<END>>')[0]
        print("[OK] Delimiter '<<END>>' found")
    else:
        message = raw
        print("[WARNING] Delimiter not found, returning raw text")

    print(f"[OK] Extracted message: '{message}'")

    if output_path:
        os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
        with open(output_path, 'w') as f:
            f.write(message + '\n')
        print(f"[OK] Saved to: {output_path}")

    return message

def main():
    parser = argparse.ArgumentParser(description='LSB Extract')
    parser.add_argument('--input', '-i', required=True)
    parser.add_argument('--output', '-o', default=None)
    args = parser.parse_args()
    print("="*55); print("  LSB STEGANOGRAPHY - EXTRACT"); print("="*55)
    extract_message(args.input, args.output)
    print("="*55)

if __name__ == '__main__':
    main()
