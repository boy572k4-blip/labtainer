#!/usr/bin/env python3
"""
lsb_extract.py - Trích xuất thông điệp ẩn từ ảnh PNG đã nhúng LSB

Cách hoạt động:
  1. Đọc bit thấp nhất (LSB) của từng kênh màu (R,G,B) theo thứ tự
  2. Ghép các bit thành byte (8 bit = 1 ký tự)
  3. Dừng khi gặp delimiter kết thúc (16 byte null)
  4. Trả về thông điệp gốc
"""

import sys
import os
import argparse

try:
    from PIL import Image
except ImportError:
    os.system("pip3 install Pillow --break-system-packages 2>/dev/null || pip3 install Pillow")
    from PIL import Image


# Phải khớp với delimiter trong lsb_embed.py
END_DELIMITER = '\x00' * 16
END_BITS = len(END_DELIMITER) * 8  # 128 bit


def bits_to_text(bits):
    """Chuyển danh sách bit thành chuỗi văn bản"""
    chars = []
    for i in range(0, len(bits) - 7, 8):
        byte = 0
        for j in range(8):
            byte = (byte << 1) | bits[i + j]
        if byte == 0:
            chars.append('\x00')
        else:
            try:
                chars.append(chr(byte))
            except ValueError:
                chars.append('?')
    return ''.join(chars)


def extract_message(stego_path, output_path=None):
    """Trích xuất thông điệp từ ảnh PNG đã nhúng LSB"""
    try:
        img = Image.open(stego_path)
    except FileNotFoundError:
        print(f"[ERROR] Không tìm thấy ảnh: {stego_path}")
        sys.exit(1)

    if img.mode != 'RGB':
        img = img.convert('RGB')

    width, height = img.size
    pixels = [img.getpixel((x,y)) for y in range(img.size[1]) for x in range(img.size[0])]

    print(f"[INFO] Đang phân tích ảnh: {stego_path}")
    print(f"       Kích thước: {width}x{height} pixels")
    print(f"       Tổng pixels: {len(pixels)}")

    # Thu thập LSB từ mỗi kênh màu
    bits = []
    for pixel in pixels:
        r, g, b = pixel[0], pixel[1], pixel[2]
        bits.append(r & 1)
        bits.append(g & 1)
        bits.append(b & 1)

    # Chuyển bit thành text, tìm delimiter
    null_count = 0
    result_bits = []
    found_end = False

    for i in range(0, len(bits) - 7, 8):
        byte_bits = bits[i:i+8]
        byte_val = 0
        for b in byte_bits:
            byte_val = (byte_val << 1) | b

        result_bits.extend(byte_bits)

        if byte_val == 0:
            null_count += 1
            if null_count >= 16:
                # Đã tìm thấy delimiter, dừng
                # Loại bỏ các byte null ở cuối
                result_bits = result_bits[:-(null_count * 8)]
                found_end = True
                break
        else:
            null_count = 0

    if not found_end:
        print("[WARNING] Không tìm thấy delimiter kết thúc. Ảnh có thể không chứa thông điệp hợp lệ.")
        # Cố gắng đọc đến byte đầu tiên có giá trị 0
        result_bits = []
        for i in range(0, min(len(bits), 10000), 8):
            byte_bits = bits[i:i+8]
            byte_val = sum(b << (7-j) for j, b in enumerate(byte_bits))
            if byte_val == 0:
                break
            result_bits.extend(byte_bits)

    # Decode message
    message = bits_to_text(result_bits)

    print(f"[OK] Trích xuất thành công!")
    print(f"     Thông điệp: '{message}'")
    print(f"     Độ dài: {len(message)} ký tự ({len(message)} bytes)")

    # Lưu ra file nếu có chỉ định
    if output_path:
        os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(message + '\n')
        print(f"[OK] Đã lưu thông điệp vào: {output_path}")

    return message


def main():
    parser = argparse.ArgumentParser(
        description='LSB Steganography - Trích xuất thông điệp từ ảnh PNG',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Ví dụ:
  python3 lsb_extract.py --input stego.png
  python3 lsb_extract.py --input stego.png --output extracted_message.txt
        """
    )
    parser.add_argument('--input',  '-i', required=True, help='Đường dẫn ảnh stego PNG')
    parser.add_argument('--output', '-o', default=None,  help='File lưu thông điệp (tuỳ chọn)')

    args = parser.parse_args()

    print("=" * 60)
    print("  LSB STEGANOGRAPHY - TRÍCH XUẤT THÔNG ĐIỆP TỪ ẢNH PNG")
    print("=" * 60)
    extract_message(args.input, args.output)
    print("=" * 60)


if __name__ == '__main__':
    main()
