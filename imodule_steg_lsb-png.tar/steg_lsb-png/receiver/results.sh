#!/bin/bash
RESULT_DIR=/home/ubuntu/.local/result
mkdir -p $RESULT_DIR

# Check extracted_message.txt
if [ -f /home/ubuntu/steg_lab/extracted_message.txt ]; then
    echo "1" > $RESULT_DIR/extracted_message
else
    echo "0" > $RESULT_DIR/extracted_message
fi

# Check chi_square đã chạy (kiểm tra qua bash history)
if grep -q "chi_square_test.py" /home/ubuntu/.bash_history 2>/dev/null; then
    echo "1" > $RESULT_DIR/chi_square_run
else
    echo "0" > $RESULT_DIR/chi_square_run
fi

chown -R ubuntu:ubuntu $RESULT_DIR
