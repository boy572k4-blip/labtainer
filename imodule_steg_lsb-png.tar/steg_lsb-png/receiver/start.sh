#!/bin/bash
service ssh start
mkdir -p /home/ubuntu/steg_lab
echo "[READY] Receiver sẵn sàng! IP: 172.21.0.30"
tail -f /dev/null
