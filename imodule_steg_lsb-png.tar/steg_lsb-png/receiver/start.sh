#!/bin/bash
service ssh start

# Tạo thư mục lab cho ubuntu
mkdir -p /home/ubuntu/steg_lab
chown -R ubuntu:ubuntu /home/ubuntu/steg_lab

# Symlink để root cũng dùng được ~/steg_lab/
ln -sfn /home/ubuntu/steg_lab /root/steg_lab

echo "[READY] Receiver san sang! IP: 172.21.0.30"
echo "[INFO]  Thu muc lab: /home/ubuntu/steg_lab  hoac  ~/steg_lab"
tail -f /dev/null
