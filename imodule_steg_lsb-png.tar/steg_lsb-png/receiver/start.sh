#!/bin/bash
service ssh start 2>/dev/null

mkdir -p /var/labtainer
echo "steg_lsb-png_seed" > /var/labtainer/seed

mkdir -p /home/ubuntu/.local
echo "steg_lsb-png_seed" > /home/ubuntu/.local/.seed
echo "student@labtainer.local" > /home/ubuntu/.local/.email
echo "steg_lsb-png" > /home/ubuntu/.local/.labname
chown -R ubuntu:ubuntu /home/ubuntu/.local

touch /var/labtainer/did_param

mkdir -p /home/ubuntu/steg_lab
chown -R ubuntu:ubuntu /home/ubuntu/steg_lab

tail -f /dev/null
