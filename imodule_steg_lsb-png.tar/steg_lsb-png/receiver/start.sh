#!/bin/bash
service ssh start
echo "[READY] Receiver sẵn sàng! IP: 172.21.0.30"
echo "[INFO] Workspace: /root/steg_lab/"
echo "[INFO] Chờ ảnh stego từ sender (172.21.0.21)..."
tail -f /dev/null
